import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ProductDetails extends StatelessWidget {
  final String image, ProductName, ProductType, Price, weight;

  ProductDetails({
    required this.image,
    required this.ProductName,
    required this.ProductType,
    required this.Price,
    required this.weight,
  });
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
