import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

import '../Apiconnect/ApiConnect.dart';
import '../Forms/AppSnackBar.dart';
import '../Models/PlaceOrdeItemResponse.dart';
import '../Pojo/GetCartProductResponse.dart';
import '../Provider/ProductProvider.dart';
import '../utility/AppPreference.dart';
import '../utility/BottomNavigationBar.dart';

class CartScreenController extends GetxController {
  RxInt selectedTabIndex = 0.obs;
  late RxList<CartData> CartProdct = RxList();
  var selectedButton = 1.obs; // 0 = none, 1 = first button, 2 = second button
  RxString checkOut = RxString("Checkout");
  RxString selectSlot = RxString("Select a Slot");
  RxString address = RxString("");
  late RxList<PlaceOrderItemsResponse> placeOrderItems = RxList();
  RxList<RxInt> productPriceDuplicate = RxList<RxInt>();
  // Rx<GetCartResponse?> cartResponse = Rx<GetCartResponse?>(null);
  // DeleteCartResponse deletecartResponse = DeleteCartResponse();
  TextEditingController pickUptimeController = TextEditingController();

  TextEditingController mobileNumberController = TextEditingController();
  TextEditingController productCategoryController = TextEditingController();
  RxString productCategoryDropdown = RxString('Enter Product Category'.tr);
  final selectedCategory = ''.obs;
  final ApiConnect _connect = Get.put(ApiConnect());
  bool isSelectCall = false;
  bool isCall = false;
  RxInt count = RxInt(0); // Observable integer
  late ProductProvider userDataProvider;
  RxList<bool> onClickList = RxList();
  RxBool isClicked = RxBool(false);
  RxBool isAddressSelected = RxBool(false);
  RxList<bool> onClickCounterList = RxList();
  RxBool isLoading = RxBool(false);
  int index = 0;
  RxString pickupMethods = RxString("");
  RxString UpdatePrice = RxString("");
  RxString UpdateTotalPrice = RxString("0");
  RxList<RxInt> counter = RxList<RxInt>([RxInt(1)]);
  int selectedIndex = 0;
  RxInt selectedIndexOne = RxInt(0);
  final List<String> categories = [
    'Cash On Delivery',
    'Net Banking',
    'Upi Payment',
  ];

// RxList <RxString> UpdatePrice =  RxList<RxString> ([RxString("")]);
  paymentProcess() async {
    for (int i = 0; i < onClickList.length; i++) {
      if (onClickList[i] == true) {
        isClicked.value = true;
        selectedIndex = i;
        break;
      }
    }

    if (isClicked.value == false) {
      Fluttertoast.showToast(
        msg: "Select the Time Slot",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: Colors.black,
        textColor: Colors.white,
      );
      return;
    }
  }

  @override
  void onInit() async {
    super.onInit();
    userDataProvider = Provider.of<ProductProvider>(Get.context!, listen: false);
    address.value = userDataProvider.getLocation.toString();

    GetCartApi();
    // initializeCartPrices();
  }

  // void initializeCartPrices() {
  //   for (int i = 0; i < CartProdct.length; i++) {
  //     int price = int.tryParse(CartProdct[i].productPriceDuplicate ?? '0') ?? 0;
  //     int quantity = CartProdct[i].cartQty ?? 1;
  //     int totalItemPrice = price * quantity;
  //
  //     CartProdct[i].productPrice = totalItemPrice.toString();
  //   }
  //
  //   // Optionally, calculate the total price for all items
  //   calculateTotalPrice();
  // }
  //
  // void calculateTotalPrice() {
  //   int total = 0;
  //
  //   for (int i = 0; i < CartProdct.length; i++) {
  //     int itemPrice = int.tryParse(CartProdct[i].productPriceDuplicate ?? '0') ?? 0;
  //     total += itemPrice;
  //   }
  //
  //   UpdateTotalPrice.value = total.toString();
  //   print("Total price for all items: ${UpdateTotalPrice.value}");
  // }
  void calculateTotalPrice() {
    int total = 0;
    for (var product in CartProdct) {
      int unitPrice = int.tryParse(product.productPriceDuplicate ?? '0') ?? 0;
      int quantity = product.cartQty ?? 1;
      total += unitPrice * quantity;
    }
    UpdateTotalPrice.value = total.toString();
  }

  void incrementCounter(int index) {
    isLoading.value = true;
    if (index >= 0 && index < CartProdct.length) {
      // Increment the quantity
      CartProdct[index].cartQty = (CartProdct[index].cartQty ?? 0) + 1;

      // Calculate the price for the updated quantity
      int price = int.tryParse(CartProdct[index].productPriceDuplicate ?? '0') ?? 0;
      num result = price * CartProdct[index].cartQty!;
      CartProdct[index].productPrice = result.toString();

      // Update the total price for all products
      calculateTotalPrice();
    }
    isLoading.value = false;
  }

  void decrementCounter(int index) {
    isLoading.value = true;
    if (index >= 0 && index < CartProdct.length && (CartProdct[index].cartQty ?? 1) > 1) {
      // Decrement the quantity
      CartProdct[index].cartQty = (CartProdct[index].cartQty ?? 0) - 1;

      // Calculate the price for the updated quantity
      int price = int.tryParse(CartProdct[index].productPriceDuplicate ?? '0') ?? 0;
      num result = price * CartProdct[index].cartQty!;
      CartProdct[index].productPrice = result.toString();

      // Update the total price for all products
      calculateTotalPrice();
    }
    isLoading.value = false;
  }

  // void decrementCounter(int index) {
  //   isLoading.value = true;
  //
  //   if (index >= 0 && index < counter.length && counter[index].value > 1) {
  //     counter[index].value--;
  //   }
  //   int price = int.tryParse(CartProdct[index].productPriceDuplicate ?? '0') ?? 0;
  //   int result = price * counter[index].value;
  //   UpdatePrice.value = result.toString();
  //   CartProdct[index].productPrice = UpdatePrice.value;
  //
  //   log(json.encode(CartProdct));
  //
  //   isLoading.value = false;
  // }

  void updatePrice(int index) {
    if (index >= 0 && index < CartProdct.length && index < counter.length) {}
  }

  void increment() {
    count++;
  }

  GetCartApi() async {
    Map<String, dynamic> payload = {
      'customerId': AppPreference().UserId,
      'productId': "",
    };
    print(payload);
    isLoading.value = true;
    var response = await _connect.GetCart(payload);

    print("CartScreen${response.toJson()}");
    onClickList.clear();
    counter.clear();
    if (!response.error!) {
      print('check cart api');
      CartProdct.value = response.data!;
      productPriceDuplicate.clear();
      for (var data in response.data!) {
        productPriceDuplicate.add(RxInt(int.tryParse(data.productPrice) ?? 0));
      }
      debugPrint("getAttesrghrndanceList: ${response.toJson()}");
      for (int i = 0; i < response.data!.length; i++) {
        counter.add(RxInt(1));
        calculateTotalPrice();
        update();
      }
    } else {}
    isLoading.value = false;
  }

  GetCartPlaceItemsApi(context) async {
    List<Map<String, dynamic>> ballonMakingJsonList = placeOrderItems.map((item) => item.toJson()).toList();

    String BallonMarking = jsonEncode(ballonMakingJsonList);

    placeOrderItems.clear();
    for (int i = 0; i < CartProdct.length; i++) {
      PlaceOrderItemsResponse placeItems = PlaceOrderItemsResponse();
      placeItems.productName = CartProdct[index].productName.toString();
      placeItems.productId = CartProdct[index].productId.toString();
      placeItems.productPrice = CartProdct[index].productPrice.toString();
      placeItems.productQty = CartProdct[index].productQty.toString();
      placeItems.orderedQty = counter[index].toString();
      placeOrderItems.add(placeItems);

      String productPrice = CartProdct[i].productPrice.toString();
      String updatePrice = UpdateTotalPrice.value;
      int num1 = int.parse(productPrice);
      int num2 = int.parse(updatePrice);
      int result = num1 + num2;
      UpdateTotalPrice.value = result.toString();
      print(" Total price : ${UpdateTotalPrice.value}");
    }
    print("placeOrderItems ${json.encode(placeOrderItems)}");

    Map<String, dynamic> payload = {
      "items": json.encode(placeOrderItems),
      "sellerId": CartProdct[0].sellerId,
      "customerId": AppPreference().UserId.toString(),
      "firstPromoOffer": "",
      "totalOrderCost": UpdateTotalPrice.value,
      "paymentOption": productCategoryController.text,
      "pickupTime": AppPreference().pickup == "PickUp" ? pickUptimeController.text : "0",
      "deliveryFee": "30",
      "deliveryOption": pickupMethods.value,
      "deliveryTime": "",
      "deliveryMobileNo": mobileNumberController.text
    };
    print("PlaceOrderpayload${payload}");
    isLoading.value = true;
    var response = await _connect.PlaceOrderList(payload);
    isLoading.value = false;

    print("Response${response.toJson()}");
    if (!response.error!) {
      Fluttertoast.showToast(
        msg: response.message!,
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: Colors.black,
        textColor: Colors.white,
      );
      pickUptimeController.text = "";
      UpdateTotalPrice.value.isEmpty;
      pickupMethods.value.isEmpty;
      mobileNumberController.text = "";
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => navigateBar()),
      );
    }
  }

  DeleteCartApi() async {
    // Ensure the index is valid before attempting to access CartProdct
    // if (index < 0 || index >= CartProdct.length) {
    //   Fluttertoast.showToast(
    //     msg: "Invalid product index.",
    //     toastLength: Toast.LENGTH_SHORT,
    //     gravity: ToastGravity.BOTTOM,
    //     backgroundColor: Colors.red,
    //     textColor: Colors.white,
    //   );
    //   return; // Exit early if the index is invalid
    // }

    // Prepare the payload for the delete API call
    Map<String, dynamic> payload = {
      'userId': AppPreference().UserId,
      'productId': CartProdct.value[index].productId, // Assuming id is the correct field
    };

    print("Deleting product: $payload");

    // Call the delete API
    var response = await _connect.DeleteCart(payload);
    print("Delete API Called: ${response.toJson()}");

    // Check for errors in the response
    if (response.error != true) {
      Fluttertoast.showToast(
        msg: response.message ?? "Product deleted successfully.",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: Colors.black,
        textColor: Colors.white,
      );

      print('Product deleted successfully. Checking cart again.');

      // Refresh the cart items after deletion
      GetCartApi(); // Call to refresh the cart
    } else {
      // Show error message if the deletion fails
      AppSnackBar.error(message: response.message ?? "Error deleting product.");
    }
  }

  updateCartQuantities() async {
    // Create payload after storing the response
    Map<String, dynamic> requestPayload = createPayload();

    if (requestPayload.isNotEmpty) {
      // Send the payload to updateCartQuantities only if it's not empty
      await _connect.updateCartQuantities(requestPayload);
    } else {
      print("Request Payload is empty, skipping API call.");
    }
  }

  Map<String, dynamic> createPayload() {
    Map<String, dynamic> payload = {"customerId": AppPreference().UserId, "quantities": {}};

    // Check if CartProdct has data
    if (CartProdct.value != null) {
      for (CartData item in CartProdct.value!) {
        if (item.cartId != null && item.cartQty != null) {
          // Add each cart item to the cartItems map with `cartId` as key and `cartQty` as value
          payload["quantities"][item.cartId.toString()] = item.cartQty as int;
        } else {
          print("Skipped item with null cartId or cartQty: ${item.toJson()}");
        }
      }
    } else {
      print("CartProdct is null or empty");
    }

    print("Final payload: ${jsonEncode(payload)}");
    return payload;
  }
}
