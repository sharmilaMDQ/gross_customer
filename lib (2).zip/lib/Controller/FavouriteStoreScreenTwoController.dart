import 'package:get/get.dart';

class FavouriteStoreScreenTwoController extends GetxController {
  @override
  void onInit() async {
    super.onInit();
  }
}
