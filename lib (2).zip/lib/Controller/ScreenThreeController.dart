import 'package:carousel_slider/carousel_controller.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';

class ScreenThreeController extends GetxController {
  final CarouselController carouselController = CarouselController();

  RxInt current = RxInt(0);
  RxString currentIndex = RxString('');

  RxString headingText = RxString('Shop From Anywhere');
  RxString SubHeadingText = RxString(
    'Shop local flyers & deal and earn \n       '
    ' our optimum points ',
  );
  RxString Buttons = RxString('Next');

  List<String> productImages = [
    'assets/images/shopimage.png',
    'assets/images/Deliver.png',
  ];

  @override
  void onInit() async {
    super.onInit();
    updateTabIndex(current.value);
  }

  updateTabIndex(int index) {
    print('INDEXHEAD$current');
    if (current.value == 1) {
      headingText.value = 'Pick and Delivery';
      SubHeadingText.value = 'Pick up your orders in-store or have \n       '
          ' it delivered to your door ';
      Buttons.value = 'Got it';
      update();
      print('HEAD$headingText');
      print(headingText.value);
    } else {
      headingText.value = 'Shop From Anywhere';
      SubHeadingText.value = '   Shop local flyers & deal and earn \n       '
          '    our optimum points ';
      Buttons.value = 'Next';
      update();
      print('HEAD$headingText');
      print(headingText.value);
    }
  }
}
