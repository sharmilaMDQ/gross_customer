import 'package:date_format/date_format.dart';
import 'package:flutter/material.dart';
import 'package:flutter_time_picker_spinner/flutter_time_picker_spinner.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:grosshop/UI/Addresses/addNewAddressScreen.dart';
import 'package:grosshop/UI/CartScreen/checkOutScreen.dart';
import 'package:grosshop/utility/BottomNavigationBar.dart';
import 'package:intl/intl.dart';

import '../../Components/AppTheme.dart';
import '../../Components/CartCommonComponent.dart';
import '../../Components/Forms.dart';
import '../../Controller/CartScreenController.dart';
import '../../Forms/AppSnackBar.dart';

class CartScreen extends GetView<CartScreenController> {
  CartScreen({Key? key}) : super(key: key);

  bool isSelected = false;

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.height;
    CartScreenController Controller = Get.put(CartScreenController());
    WidgetsBinding.instance?.addPostFrameCallback((_) {
      // controller.GetCartApi();
    });

    // String formatAmount(int amount) {
    //   final formatter = NumberFormat('#,##0');
    //   return formatter.format(amount);
    // }
    String formatAmount(String amount) {
      final formatter = NumberFormat('#,##0');
      int parsedAmount = int.tryParse(amount) ?? 0; // Parse the string to int
      return formatter.format(parsedAmount);
    }

    Controller.UpdateTotalPrice.value = "0";
    for (int i = 0; i < Controller.CartProdct.length; i++) {
      String productPrice = Controller.CartProdct[i].productPrice.toString();
      String updatePrice = Controller.UpdateTotalPrice.value;
      int num1 = int.parse(productPrice);
      int num2 = int.parse(updatePrice);
      int result = num1 + num2;
      Controller.UpdateTotalPrice.value = result.toString();
      print(" Total price : ${Controller.UpdateTotalPrice.value}");
    }
    print("jtjftjfd${controller.CartProdct.length}");
    return GetBuilder<CartScreenController>(
      init: CartScreenController(),
      builder: (controller) {
        return Theme(
          data: Theme.of(context).copyWith(
            dividerTheme: const DividerThemeData(
              color: Colors.transparent,
            ),
          ),
          child: WillPopScope(
            onWillPop: () async {
              Get.off(navigateBar());
              return false;
            },
            child: Scaffold(
              persistentFooterButtons: [
                controller.CartProdct.value.isNotEmpty
                    ? Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(14.0),
                            child: Row(
                              children: [
                                SizedBox(
                                  height: 20,
                                ),
                                Obx(() => Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 10),
                                      child: Center(
                                        child: TextButton(
                                          style: TextButton.styleFrom(
                                            splashFactory: NoSplash.splashFactory,
                                            elevation: 0,
                                            backgroundColor:
                                                controller.selectedButton.value == 1 ? AppTheme.Buttoncolor.withOpacity(0.5) : Colors.white,

                                            side: BorderSide(
                                              color: controller.selectedButton.value == 1 ? AppTheme.Buttoncolor : Colors.grey.withOpacity(0.5),
                                            ),
                                            shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.circular(8),
                                            ),
                                            padding: EdgeInsets.symmetric(vertical: 10, horizontal: 36), // Height approximation
                                          ),
                                          onPressed: () {
                                            controller.selectedButton.value = 1;
                                            controller.userDataProvider.setGetItNow(controller.selectedButton.value.toString());
                                            // Get.to(CheckOutScreen());
                                          },
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              Text.rich(
                                                TextSpan(
                                                  children: [
                                                    WidgetSpan(
                                                      child: Icon(
                                                        Icons.electric_bolt_sharp, // Choose your icon
                                                        size: 16, // Adjust the icon size to match text
                                                        color: Colors.black,
                                                      ),
                                                    ),
                                                    TextSpan(
                                                      text: " Get it now",
                                                      style: GoogleFonts.poppins(
                                                        color: Colors.black,
                                                        fontSize: 13,
                                                        fontWeight: FontWeight.w400,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Text(
                                                "Get it in minutes",
                                                style: GoogleFonts.poppins(
                                                  color: Colors.black,
                                                  fontSize: 13,
                                                  fontWeight: FontWeight.w400,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    )),
                                const SizedBox(height: 20),
                                Obx(() => Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 0),
                                      child: Center(
                                        child: TextButton(
                                          style: TextButton.styleFrom(
                                            splashFactory: NoSplash.splashFactory,
                                            elevation: 0,
                                            backgroundColor:
                                                controller.selectedButton.value == 2 ? AppTheme.Buttoncolor.withOpacity(0.5) : Colors.white,
                                            side: BorderSide(
                                              color: controller.selectedButton.value == 2 ? AppTheme.Buttoncolor : Colors.grey.withOpacity(0.5),
                                            ),
                                            shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.circular(8),
                                            ),
                                            padding: EdgeInsets.symmetric(vertical: 10, horizontal: 36), // Height approximation
                                          ),
                                          onPressed: () {
                                            controller.selectedButton.value = 2;
                                            controller.userDataProvider.setGetItNow(controller.selectedButton.value.toString());
                                            // Get.to(CheckOutScreen());
                                          },
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              Text.rich(
                                                TextSpan(
                                                  children: [
                                                    WidgetSpan(
                                                      child: Icon(
                                                        Icons.schedule, // Choose your icon
                                                        size: 16, // Adjust the icon size to match text
                                                        color: Colors.black,
                                                      ),
                                                    ),
                                                    TextSpan(
                                                      text: " Schedule delivery",
                                                      style: GoogleFonts.poppins(
                                                        color: Colors.black,
                                                        fontSize: 13,
                                                        fontWeight: FontWeight.w400,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Text(
                                                "Get it in 2 hrs",
                                                style: GoogleFonts.poppins(
                                                  color: Colors.black,
                                                  fontSize: 13,
                                                  fontWeight: FontWeight.w400,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    )),
                                const SizedBox(height: 20),
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 10),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Center(
                                    child: Obx(
                                      () => Text(
                                        "Total: ₹  ${controller.UpdateTotalPrice.value} ",
                                        style: GoogleFonts.roboto(
                                          color: Colors.black,
                                          fontSize: 19,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Center(
                                    child: Button(
                                        heightFactor: 0.06,
                                        onPressed: () {
                                          // Controller.UpdateTotalPrice.value = "0";
                                          // for (int i = 0; i < Controller.CartProdct.length; i++) {
                                          //   String productPrice = Controller.CartProdct[i].productPrice.toString();
                                          //   String updatePrice = Controller.UpdateTotalPrice.value;
                                          //   int num1 = int.parse(productPrice);
                                          //   int num2 = int.parse(updatePrice);
                                          //   int result = num1 + num2;
                                          //   Controller.UpdateTotalPrice.value = result.toString();
                                          //   print(" Total price : ${Controller.UpdateTotalPrice.value}");
                                          // }
                                          controller.updateCartQuantities();
                                          print("controllerssss");
                                          Get.to(() => CheckOutScreen());
                                        },
                                        child: Obx(
                                          () => Text(
                                            controller.selectedButton.value == 1
                                                ? controller.checkOut.toString()
                                                : controller.selectSlot.toString(), //bottomsheet button
                                            style: GoogleFonts.poppins(
                                              color: Colors.white,
                                              fontSize: 18,
                                              fontWeight: FontWeight.w400,
                                            ),
                                          ),
                                        )),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      )
                    : Container(),
              ],
              // backgroundColor: AppTheme.Buttoncolor,

              appBar: AppBar(
                backgroundColor: AppTheme.Buttoncolor,
                automaticallyImplyLeading: false,
                bottomOpacity: 0.0,
                elevation: 0.0,
                toolbarHeight: 50,
                // leading: Padding(
                //   padding: EdgeInsets.only(top: 20, bottom: 20, right: 0, left: 15),
                //   child: InkWell(
                //     onTap: () {
                //       Navigator.pop(context);
                //     },
                //     child: Container(
                //       decoration: BoxDecoration(
                //           color: Colors.green.shade700,
                //           borderRadius: BorderRadius.circular(10)),
                //       margin: EdgeInsets.symmetric(
                //         horizontal: 2,
                //       ),
                //       child: Icon(
                //         Icons.arrow_back_ios_new,
                //         color: Colors.white, // customize color as per requirement
                //       ),
                //     ),
                //   ),
                // ),
                leading: Padding(
                  padding: EdgeInsets.only(top: 10, bottom: 20, right: 0, left: 15),
                  child: InkWell(
                    onTap: () {
                      // controller.userDataProvider.getCounterClear;
                      Get.off(() => navigateBar());
                    },
                    /*child: Container(
                      decoration: BoxDecoration(color: Colors.green.shade700, borderRadius: BorderRadius.circular(10)),
                      margin: EdgeInsets.symmetric(
                        horizontal: 2,
                      ),*/
                    child: Icon(
                      Icons.arrow_back_ios_new,
                      color: Colors.white, // customize color as per requirement
                    ),
                    /*),*/
                  ),
                ),
                title: Text("My cart detail",
                    style: GoogleFonts.poppins(
                      color: Colors.white,
                      fontSize: 17,
                      fontWeight: FontWeight.w600,
                    )),
                centerTitle: true,
                actions: <Widget>[],
              ),

              body: SingleChildScrollView(
                child: Container(
                  decoration: BoxDecoration(
                      color: AppTheme.ScreenBackground, borderRadius: BorderRadius.only(topLeft: Radius.circular(25), topRight: Radius.circular(25))),
                  child: Obx(
                    () => Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: controller.isLoading.value
                          ? const Center(child: CircularProgressIndicator())
                          : controller.CartProdct.isNotEmpty
                              ? Column(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(top: 50),
                                      child: Container(
                                        height: height * 0.02,
                                        decoration: BoxDecoration(color: Colors.white24),
                                        child: Row(
                                          children: [
                                            Text.rich(
                                              TextSpan(
                                                children: [
                                                  const WidgetSpan(
                                                    child: Icon(
                                                      Icons.location_on_outlined, // Choose your icon
                                                      size: 16, // Adjust the icon size to match text
                                                      color: Colors.black,
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: " Deliver to",
                                                    style: GoogleFonts.poppins(
                                                      color: Colors.black,
                                                      fontSize: 13,
                                                      fontWeight: FontWeight.w400,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Row(
                                              children: [
                                                Text(
                                                  " Office",
                                                  style: GoogleFonts.poppins(
                                                    color: Colors.black,
                                                    fontSize: 13,
                                                    fontWeight: FontWeight.w400,
                                                  ),
                                                ),
                                                Center(child: const Icon(Icons.arrow_drop_down)),
                                                Padding(
                                                  padding: const EdgeInsets.only(left: 170),
                                                  child: InkWell(
                                                    onTap: () {
                                                      Get.to(() => AddNewAddressScreen());
                                                    },
                                                    child: Container(
                                                      height: height * 0.4,
                                                      width: width * 0.1,
                                                      decoration: BoxDecoration(
                                                        color: AppTheme.Buttoncolor.withOpacity(0.3),
                                                        border: Border.all(
                                                          color: AppTheme.Buttoncolor,
                                                        ),
                                                        borderRadius: BorderRadius.circular(1),
                                                      ),
                                                      child: Center(
                                                        child: Text(
                                                          "Change",
                                                          style: GoogleFonts.poppins(
                                                            color: Colors.black,
                                                            fontSize: 12,
                                                            fontWeight: FontWeight.w400,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Obx(() => Expanded(
                                                  child: Text(
                                                    controller.address.toString(),
                                                    style: GoogleFonts.poppins(
                                                      color: Colors.black,
                                                      fontSize: 13,
                                                      fontWeight: FontWeight.w400,
                                                    ),
                                                  ),
                                                )),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(top: 10),
                                      child: Container(
                                        height: height * 0.02,
                                        decoration: BoxDecoration(color: Colors.white24),
                                        child: Row(
                                          children: [
                                            Text(
                                              "Delivery in 8 minutes",
                                              style: GoogleFonts.poppins(
                                                color: Colors.black,
                                                fontSize: 14,
                                                fontWeight: FontWeight.w400,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Row(children: [
                                      SizedBox(
                                        height: MediaQuery.of(context).size.height * 0.01,
                                      )
                                    ]),
                                    GridView.count(
                                      physics: NeverScrollableScrollPhysics(),
                                      crossAxisCount: 1,
                                      childAspectRatio: 3,
                                      shrinkWrap: true,
                                      children: List.generate(
                                        Controller.CartProdct.length,
                                        (index) {
                                          // Calculate price for each product based on quantity
                                          int unitPrice = int.tryParse(controller.CartProdct[index].productPriceDuplicate ?? '0') ?? 0;
                                          int quantity = controller.CartProdct[index].cartQty ?? 1;
                                          int totalItemPrice = unitPrice * quantity;

                                          return Card(
                                            shadowColor: Colors.grey.withOpacity(0.5),
                                            color: Colors.white,
                                            elevation: 5,
                                            shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.circular(10),
                                            ),
                                            child: Row(
                                              children: [
                                                CartCommonComponent(
                                                  productImage: controller.CartProdct[index].productImage ?? "",
                                                  productName: controller.CartProdct[index].productName ?? "",
                                                  productQty: controller.CartProdct[index].productQty ?? "",
                                                  productPriceChangeable: totalItemPrice.toString(),
                                                  productPrice:
                                                      controller.CartProdct[index].productPriceDuplicate ?? "", // Display calculated price here
                                                  productDescription: controller.CartProdct[index].productDescription ?? "",
                                                  productDiscountPrice: controller.CartProdct[index].productDiscountPrice.toString(),
                                                  discountAvailable: controller.CartProdct[index].discountAvailable,
                                                  OnPressed: () {
                                                    controller.DeleteCartApi();
                                                    controller.index = index;
                                                  },
                                                  decrementCounter: () {
                                                    controller.decrementCounter(index);
                                                  },
                                                  incrementCounter: () {
                                                    controller.incrementCounter(index);
                                                  },
                                                  counter: controller.CartProdct[index].cartQty ?? 1,
                                                ),
                                              ],
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                                  ],
                                )
                              : Center(
                                  child: Container(
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        SizedBox(height: 100),
                                        Image.asset("assets/images/nodata.png"),
                                        SizedBox(height: 20),
                                      ],
                                    ),
                                  ),
                                ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  showBottomTimePicker(
    BuildContext context,
    TextEditingController controller,
  ) {
    var times;
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(16.0),
          topRight: Radius.circular(16.0),
        ),
      ),
      isScrollControlled: true,
      context: context,
      builder: (BuildContext context) {
        return Builder(
          builder: (BuildContext context) {
            return Container(
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10)),
              height: 280,
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 10, right: 10, top: 15, bottom: 7),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(height: 20, width: 20),
                        Expanded(
                          child: Container(
                            alignment: Alignment.center,
                            child: Text("Select Time",
                                textAlign: TextAlign.center, style: TextStyle(color: AppTheme.appBlack, fontSize: 16, fontWeight: FontWeight.bold)),
                          ),
                        ),
                        GestureDetector(
                            onTap: () {
                              Get.back();
                            },
                            child: Icon(Icons.clear))
                      ],
                    ),
                  ),
                  Expanded(
                    child: TimePickerSpinner(
                      is24HourMode: false,
                      spacing: 30,
                      itemHeight: 37,
                      itemWidth: 60,
                      isForce2Digits: true,
                      onTimeChange: (time) {
                        times = time;
                      },
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      AppButton2(
                        width: width * 0.45,
                        height: 40,
                        title: 'Cancel',
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        onPressed: () {
                          Get.back();
                        },
                        color: Colors.white,
                        titleColor: AppTheme.bottomTabsLabelInActiveColor,
                        borderColor: AppTheme.cancelBorder,
                      ),
                      AppButton2(
                        width: width * 0.45,
                        height: 40,
                        title: 'Save ',
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        onPressed: () {
                          controller.text = " ${formatDate(times, [
                                hh,
                                ':',
                                nn,
                                ' ',
                                am,
                              ])}";
                          Navigator.of(context).pop();
                        },
                        titleColor: Colors.white,
                        color: AppTheme.Buttoncolor,
                        borderColor: AppTheme.Buttoncolor,
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

// Widget PaymentDetails(BuildContext context) {
//   return GetBuilder<CartScreenController>(
//     init: CartScreenController(),
//     builder: (controller) {
//       return Scaffold(
//         backgroundColor: AppTheme.Buttoncolor,
//         appBar: AppBar(
//           backgroundColor: AppTheme.Buttoncolor,
//           automaticallyImplyLeading: false,
//           bottomOpacity: 0.0,
//           elevation: 0.0,
//           toolbarHeight: 80,
//           leading: Padding(
//             padding: EdgeInsets.only(top: 20, bottom: 20, right: 0, left: 15),
//             child: InkWell(
//               onTap: () {
//                 Navigator.of(context);
//               },
//               child: Container(
//                 decoration: BoxDecoration(
//                     color: Colors.green.shade700,
//                     borderRadius: BorderRadius.circular(10)),
//                 margin: EdgeInsets.symmetric(
//                   horizontal: 2,
//                 ),
//                 child: Icon(
//                   Icons.arrow_back_ios_new,
//                   color: Colors.white, // customize color as per requirement
//                 ),
//               ),
//             ),
//           ),
//           title: Text("Payment detail",
//               style: TextStyle(
//                 color: Colors.white,
//                 fontSize: 20,
//                 fontWeight: FontWeight.w600,
//               )),
//           centerTitle: true,
//           actions: <Widget>[],
//         ),
//         body: Container(
//           height: MediaQuery.of(context).size.height,
//           // width: MediaQuery.of(context).size.width,
//           decoration: BoxDecoration(
//               color: Colors.white,
//               borderRadius: BorderRadius.only(
//                   topLeft: Radius.circular(25),
//                   topRight: Radius.circular(25))),
//           child: SingleChildScrollView(
//             child: Column(
//               children: [
//                 SizedBox(
//                   height: MediaQuery.of(context).size.height * 0.02,
//                 ),
//                 Padding(
//                   padding: EdgeInsets.symmetric(
//                     horizontal: 20,
//                   ),
//                   child: Row(
//                     children: [
//                       Text(
//                         'Total Amount',
//                         style: TextStyle(
//                             fontSize: 20,
//                             fontWeight: FontWeight.w700,
//                             color: Colors.black),
//                       )
//                     ],
//                   ),
//                 ),
//                 Padding(
//                   padding: const EdgeInsets.symmetric(
//                       horizontal: 20, vertical: 15),
//                   child: TextFormField(
//                     decoration: InputDecoration(
//                       border: OutlineInputBorder(),
//                       enabledBorder: OutlineInputBorder(
//                         borderSide: BorderSide(color: AppTheme.Buttoncolor),
//                         borderRadius: BorderRadius.circular(25),
//                       ),
//                       focusedBorder: OutlineInputBorder(
//                         borderSide: BorderSide(color: AppTheme.Buttoncolor),
//                         borderRadius: BorderRadius.circular(20),
//                       ),
//                       hintText: '   CAD\$11.52',
//                       hintStyle: TextStyle(
//                           fontSize: 15,
//                           fontWeight: FontWeight.w400,
//                           color: Colors.black26),
//                     ),
//                     style: TextStyle(
//                         fontSize: 15,
//                         fontWeight: FontWeight.w400,
//                         color: Colors.black26),
//                   ),
//                 ),
//                 Padding(
//                   padding: EdgeInsets.symmetric(horizontal: 20),
//                   child: Row(
//                     mainAxisAlignment: MainAxisAlignment.start,
//                     children: [
//                       Text(
//                         'Payment method',
//                         style: TextStyle(
//                             fontSize: 20,
//                             fontWeight: FontWeight.w700,
//                             color: Colors.black),
//                       )
//                     ],
//                   ),
//                 ),
//                 Padding(
//                   padding: EdgeInsets.symmetric(
//                     horizontal: 20,
//                     vertical: 15,
//                   ),
//                   child: TextFormField(
//                     decoration: InputDecoration(
//                       border: OutlineInputBorder(),
//                       enabledBorder: OutlineInputBorder(
//                         borderSide: BorderSide(color: AppTheme.Buttoncolor),
//                         borderRadius: BorderRadius.circular(25),
//                       ),
//                       focusedBorder: OutlineInputBorder(
//                         borderSide: BorderSide(color: AppTheme.Buttoncolor),
//                         borderRadius: BorderRadius.circular(20),
//                       ),
//                       hintText: '   Credit card',
//                       hintStyle: TextStyle(
//                           fontSize: 15,
//                           fontWeight: FontWeight.w400,
//                           color: Colors.black26),
//                       suffixIcon: Icon(Icons.keyboard_arrow_down,
//                           size: 35, color: Colors.black26),
//                     ),
//                     style: TextStyle(
//                         fontSize: 15,
//                         fontWeight: FontWeight.w400,
//                         color: Colors.black26),
//                   ),
//                 ),
//                 Padding(
//                   padding: EdgeInsets.symmetric(horizontal: 20),
//                   child: Row(
//                     mainAxisAlignment: MainAxisAlignment.start,
//                     children: [
//                       Text(
//                         'Car expirated date',
//                         style: TextStyle(
//                             fontSize: 20,
//                             fontWeight: FontWeight.w700,
//                             color: Colors.black),
//                       )
//                     ],
//                   ),
//                 ),
//                 Padding(
//                     padding: const EdgeInsets.symmetric(
//                         horizontal: 20, vertical: 15),
//                     child: Row(
//                       children: [
//                         Expanded(
//                           child: Padding(
//                             padding: const EdgeInsets.only(right: 5),
//                             child: TextFormField(
//                               decoration: InputDecoration(
//                                 border: OutlineInputBorder(),
//                                 enabledBorder: OutlineInputBorder(
//                                   borderSide:
//                                       BorderSide(color: AppTheme.Buttoncolor),
//                                   borderRadius: BorderRadius.circular(25),
//                                 ),
//                                 focusedBorder: OutlineInputBorder(
//                                   borderSide:
//                                       BorderSide(color: AppTheme.Buttoncolor),
//                                   borderRadius: BorderRadius.circular(20),
//                                 ),
//                                 hintText: '   dd/mm/yyyy',
//                                 hintStyle: TextStyle(
//                                   fontSize: 15,
//                                   fontWeight: FontWeight.w400,
//                                   color: Colors.black26,
//                                 ),
//                                 suffixIcon: Icon(
//                                   Icons.keyboard_arrow_down,
//                                   size: 35,
//                                   color: Colors.black26,
//                                 ),
//                               ),
//                               style: TextStyle(
//                                 fontSize: 15,
//                                 fontWeight: FontWeight.w400,
//                                 color: Colors.black26,
//                               ),
//                             ),
//                           ),
//                         ),
//                         Expanded(
//                           child: Padding(
//                             padding: const EdgeInsets.only(left: 5),
//                             child: TextFormField(
//                               decoration: InputDecoration(
//                                 border: OutlineInputBorder(),
//                                 enabledBorder: OutlineInputBorder(
//                                   borderSide:
//                                       BorderSide(color: AppTheme.Buttoncolor),
//                                   borderRadius: BorderRadius.circular(25),
//                                 ),
//                                 focusedBorder: OutlineInputBorder(
//                                   borderSide:
//                                       BorderSide(color: AppTheme.Buttoncolor),
//                                   borderRadius: BorderRadius.circular(20),
//                                 ),
//                                 hintText: '   dd/mm/yyyy',
//                                 hintStyle: TextStyle(
//                                   fontSize: 15,
//                                   fontWeight: FontWeight.w400,
//                                   color: Colors.black26,
//                                 ),
//                                 suffixIcon: Icon(
//                                   Icons.keyboard_arrow_down,
//                                   size: 35,
//                                   color: Colors.black26,
//                                 ),
//                               ),
//                               style: TextStyle(
//                                 fontSize: 15,
//                                 fontWeight: FontWeight.w400,
//                                 color: Colors.black26,
//                               ),
//                             ),
//                           ),
//                         ),
//                       ],
//                     )),
//                 Padding(
//                   padding: const EdgeInsets.symmetric(horizontal: 20),
//                   child: Row(
//                     mainAxisAlignment: MainAxisAlignment.start,
//                     children: [
//                       Text(
//                         'Card number',
//                         style: TextStyle(
//                             fontSize: 20,
//                             fontWeight: FontWeight.w700,
//                             color: Colors.black),
//                       )
//                     ],
//                   ),
//                 ),
//                 Padding(
//                   padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
//                   child: TextFormField(
//                     decoration: InputDecoration(
//                       border: OutlineInputBorder(),
//                       enabledBorder: OutlineInputBorder(
//                         borderSide: BorderSide(color: AppTheme.Buttoncolor),
//                         borderRadius: BorderRadius.circular(25),
//                       ),
//                       focusedBorder: OutlineInputBorder(
//                         borderSide: BorderSide(color: AppTheme.Buttoncolor),
//                         borderRadius: BorderRadius.circular(20),
//                       ),
//                       hintText: '   Account number',
//                       hintStyle: TextStyle(
//                         fontSize: 15,
//                         fontWeight: FontWeight.w400,
//                         color: Colors.black26,
//                       ),
//                       suffixIcon: Icon(Icons.keyboard_arrow_down,
//                           size: 35, color: Colors.black26),
//                     ),
//                     style: TextStyle(
//                       fontSize: 15,
//                       fontWeight: FontWeight.w400,
//                       color: Colors.black26,
//                     ),
//                   ),
//                 ),
//                 Padding(
//                   padding: const EdgeInsets.symmetric(horizontal: 20),
//                   child: Row(
//                     mainAxisAlignment: MainAxisAlignment.start,
//                     children: [
//                       Text(
//                         'Security code',
//                         style: TextStyle(
//                           fontSize: 20,
//                           fontWeight: FontWeight.w700,
//                           color: Colors.black,
//                         ),
//                       )
//                     ],
//                   ),
//                 ),
//                 Padding(
//                   padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
//                   child: TextFormField(
//                     decoration: InputDecoration(
//                       border: OutlineInputBorder(),
//                       enabledBorder: OutlineInputBorder(
//                         borderSide: BorderSide(color: AppTheme.Buttoncolor),
//                         borderRadius: BorderRadius.circular(25),
//                       ),
//                       focusedBorder: OutlineInputBorder(
//                         borderSide: BorderSide(color: AppTheme.Buttoncolor),
//                         borderRadius: BorderRadius.circular(20),
//                       ),
//                       hintText: '   Security code',
//                       hintStyle: TextStyle(
//                           fontSize: 15,
//                           fontWeight: FontWeight.w400,
//                           color: Colors.black26),
//                       suffixIcon: Icon(Icons.keyboard_arrow_down,
//                           size: 35, color: Colors.black26),
//                     ),
//                     style: TextStyle(
//                         fontSize: 15,
//                         fontWeight: FontWeight.w400,
//                         color: Colors.black26),
//                   ),
//                 ),
//                 SizedBox(
//                   height: MediaQuery.of(context).size.height * 0.02,
//                 ),
//                 Center(
//                   child: Button(
//                     widthFactor: 0.9,
//                     heightFactor: 0.06,
//                     onPressed: () {
//                       // Navigator.push(
//                       //     context,
//                       //     MaterialPageRoute(
//                       //         builder: (context) => CreateAccountScreen()));
//                     },
//                     child: const Text(
//                       "Pay now",
//                       style: TextStyle(
//                         fontSize: 18,
//                         color: Colors.white,
//                         fontWeight: FontWeight.w600,
//                       ),
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       );
//     },
//   );
// }
}
