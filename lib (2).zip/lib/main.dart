import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:grosshop/Components/AppTheme.dart';
import 'package:grosshop/UI/LoginScreen/LoginScreen.dart';
import 'package:grosshop/utility/AppPreference.dart';
import 'package:provider/provider.dart';

import 'Pageroutes/App_pages.dart';
import 'Pageroutes/App_routes.dart';
import 'Provider/ProductProvider.dart';
import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  AppPreference().init();
  runApp(
    ChangeNotifierProvider<ProductProvider>(
      create: (_) => ProductProvider(),
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key});

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarColor: AppTheme.Buttoncolor,
      statusBarIconBrightness: Brightness.light,
    ));

    final ThemeData appTheme = ThemeData(
      appBarTheme: AppBarTheme(
        elevation: 4,
        systemOverlayStyle: SystemUiOverlayStyle.light,
        backgroundColor: AppTheme.Buttoncolor,
      ),
    );

    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      theme: appTheme,
      home: const /*ScreenOne()*/ LoginScreen(),
      initialRoute: AppRoutes.login.toName,
      getPages: AppPages.list,
    );
  }
}
