import 'package:get/get.dart';

class FavouriteStoreScreenTwoBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<FavouriteStoreScreenTwoBinding>(
        () => FavouriteStoreScreenTwoBinding());
  }
}
