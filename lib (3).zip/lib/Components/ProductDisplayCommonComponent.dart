import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../Controller/ProductHomeScreenController.dart';
import 'AppTheme.dart';

class ProductDisplayCommonComponent extends StatefulWidget {
  final String productname;
  final String shopName;
  final String productQty;
  final String productCategory;
  final int productprice;
  final String productDiscountPrice;
  final String productimage;
  final String? productDuplicatePrice;
  final bool? isFavaurite;
  final int? discountAvailable;
  final String? soldOut;
  final dynamic offerPercentage;
  final VoidCallback? onTap;
  final int counter;
  final int index;
  final VoidCallback? incrementCounter;
  final VoidCallback? decrementCounter;
  final BuildContext? outerContext;

  ProductDisplayCommonComponent({
    Key? key,
    required this.productimage,
    required this.productQty,
    required this.productprice,
    required this.shopName,
    required this.productname,
    required this.productCategory,
    required this.onTap,
    this.isFavaurite,
    required this.productDiscountPrice,
    this.productDuplicatePrice,
    this.discountAvailable,
    this.decrementCounter,
    this.incrementCounter,
    this.soldOut,
    required this.index,
    this.offerPercentage,
    this.counter = 0,
    this.outerContext,
  }) : super(key: key);

  @override
  _ProductDisplayCommonComponentState createState() => _ProductDisplayCommonComponentState();
}

class _ProductDisplayCommonComponentState extends State<ProductDisplayCommonComponent> {
  @override
  Widget build(BuildContext context) {
    ProductHomeScreenController controller = Get.put(ProductHomeScreenController());

    return Column(
      children: [
        Container(
          height: MediaQuery.of(context).size.height * 0.13,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween, // Ensures space between columns
            children: [
              Container(
                width: MediaQuery.of(context).size.width * 0.32,
                child: Column(
                  children: [
                    Container(
                      child: Stack(
                        children: <Widget>[
                          widget.productimage == null || widget.productimage.isEmpty
                              ? Container(
                                  width: MediaQuery.of(context).size.width * 0.25,
                                  height: MediaQuery.of(context).size.height * 0.06,
                                  color: Colors.white,
                                )
                              : Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Container(
                                    width: MediaQuery.of(context).size.width * 0.30,
                                    height: MediaQuery.of(context).size.height * 0.1,
                                    color: Colors.white,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(10),
                                      child: Stack(
                                        alignment: Alignment.center,
                                        children: [
                                          Image.network(
                                            '${widget.productimage}',
                                            width: MediaQuery.of(context).size.width * 0.25,
                                            height: MediaQuery.of(context).size.height * 0.1,
                                            fit: BoxFit.contain,
                                            loadingBuilder: (context, child, loadingProgress) {
                                              if (loadingProgress == null) {
                                                return child;
                                              } else {
                                                return SizedBox(
                                                  height: MediaQuery.of(context).size.height * 0.01,
                                                  width: MediaQuery.of(context).size.width * 0.02,
                                                  child: CircularProgressIndicator(
                                                    strokeWidth: 2,
                                                    color: AppTheme.Buttoncolor,
                                                  ),
                                                );
                                              }
                                            },
                                            errorBuilder: (context, error, stackTrace) {
                                              return const Icon(Icons.image);
                                            },
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                // Ensures second column takes equal space
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          width: MediaQuery.of(context).size.width * 0.30,
                          child: Text(
                            '${widget.productname}',
                            style: GoogleFonts.poppins(
                              color: Colors.black,
                              fontSize: 17,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      width: 200,
                      child: Text(
                        '${widget.productCategory}',
                        style: GoogleFonts.poppins(
                          color: Colors.black,
                          fontSize: 13,
                          fontWeight: FontWeight.w300,
                        ),
                        softWrap: true,
                      ),
                    ),
                    SizedBox(
                      width: 200,
                      child: Text(
                        '${widget.productCategory}',
                        style: GoogleFonts.poppins(
                          color: Colors.black,
                          fontSize: 13,
                          fontWeight: FontWeight.w300,
                        ),
                        softWrap: true,
                      ),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.width * 0.08,
                    ),
                    Row(
                      children: [
                        widget.discountAvailable == 0
                            ? Text(
                                '₹ ${widget.productprice}',
                                style: GoogleFonts.poppins(
                                  color: AppTheme.Buttoncolor,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                ),
                              )
                            : Row(
                                children: [
                                  Text(
                                    '(${widget.productQty})',
                                    style: GoogleFonts.poppins(
                                      color: Colors.black,
                                      fontSize: 12,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ),
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Text(
                                    '₹ ${widget.productprice}',
                                    style: GoogleFonts.poppins(
                                      color: Colors.red,
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                      decoration: TextDecoration.lineThrough,
                                    ),
                                  ),
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Text(
                                    '₹${widget.productDiscountPrice}',
                                    style: GoogleFonts.poppins(
                                      color: AppTheme.Buttoncolor,
                                      fontSize: 20,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                      ],
                    ),
                  ],
                ),
              ),
              widget.soldOut == "yes"
                  ? Padding(
                      padding: const EdgeInsets.only(right: 20),
                      child: const SizedBox(
                        child: Image(height: 90, width: 90, image: AssetImage("assets/images/SoldOut.PNG")),
                      ),
                    )
                  : Expanded(
                      // Ensures third column takes equal space
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          // First Column: Offer Percentage and Price
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                height: 30,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    widget.soldOut == "yes"
                                        ? const SizedBox()
                                        : Padding(
                                            padding: const EdgeInsets.only(left: 0),
                                            child: Text(
                                              ' ${widget.offerPercentage} % Off',
                                              style: GoogleFonts.poppins(
                                                color: Colors.black,
                                                fontSize: 15,
                                                fontWeight: FontWeight.w600,
                                              ),
                                            ),
                                          ),
                                  ],
                                ),
                              ),
                              Container(
                                height: 30,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    widget.counter > 0
                                        ? Padding(
                                            padding: const EdgeInsets.only(left: 0),
                                            child: Text(
                                              '₹ ${widget.productDuplicatePrice}',
                                              /* widget.discountAvailable == 0 ? '₹ ${widget.productDuplicatePrice}' : '₹${widget.productDiscountPrice}',*/
                                              style: GoogleFonts.poppins(
                                                color: Colors.black,
                                                fontSize: widget.discountAvailable == 0 ? 18 : 20,
                                                fontWeight: FontWeight.w600,
                                              ),
                                            ),
                                          )
                                        : Padding(
                                            padding: const EdgeInsets.only(left: 0),
                                            child: Text(
                                              '',
                                              style: GoogleFonts.poppins(
                                                color: Colors.black,
                                                fontSize: 13,
                                                fontWeight: FontWeight.w600,
                                              ),
                                            ),
                                          ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 60,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    widget.counter > 0
                                        ? Row(
                                            children: [
                                              InkWell(
                                                onTap: widget.counter > 1
                                                    ? () {
                                                        widget.decrementCounter!();
                                                      }
                                                    : () {
                                                        widget.decrementCounter!();
                                                      },
                                                child: Container(
                                                  padding: EdgeInsets.all(5),
                                                  decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(100),
                                                    color: widget.counter > 1 ? Colors.red : AppTheme.IconBackground,
                                                  ),
                                                  child: Icon(
                                                    CupertinoIcons.minus,
                                                    color: widget.counter > 1 ? Colors.white : AppTheme.Buttoncolor,
                                                    size: 15,
                                                  ),
                                                ),
                                              ),
                                              SizedBox(width: 10),
                                              Text(
                                                widget.counter.toString(),
                                                style: TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w400,
                                                  color: Colors.black,
                                                ),
                                              ),
                                              SizedBox(width: 10),
                                              InkWell(
                                                onTap: widget.incrementCounter,
                                                child: Container(
                                                  padding: EdgeInsets.all(5),
                                                  decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(100),
                                                    color: AppTheme.Buttoncolor,
                                                  ),
                                                  child: Icon(
                                                    Icons.add,
                                                    color: Colors.white,
                                                    size: 15,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          )
                                        : InkWell(
                                            onTap: widget.soldOut == "yes"
                                                ? null // Disable the button if soldOut is "yes"
                                                : () {
                                                    widget.incrementCounter?.call();
                                                  },
                                            child: Container(
                                              padding: EdgeInsets.symmetric(vertical: 9, horizontal: 20),
                                              decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(5),
                                                color: widget.soldOut == "yes" ? Colors.grey : AppTheme.Buttoncolor,
                                              ),
                                              child: Text(
                                                widget.soldOut == "yes" ? 'Sold Out' : 'Add',
                                                style: TextStyle(
                                                  color: widget.soldOut == "yes" ? Colors.black : Colors.white,
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.w600,
                                                ),
                                              ),
                                            ),
                                          ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
            ],
          ),
        ),
        Container(
          height: 2,
          child: Obx(() {
            return controller.getLoading(widget.index)
                ? const LinearProgressIndicator(
                    minHeight: 2,
                    color: AppTheme.Buttoncolor,
                    backgroundColor: Colors.white,
                  )
                : SizedBox.shrink();
          }),
        ),
      ],
    );
  }
}
