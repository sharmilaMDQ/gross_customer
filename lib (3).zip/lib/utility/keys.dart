class Keyvalues {
  String key, value;
  bool status;
  Keyvalues({required this.key, required this.value, this.status = true});
}
