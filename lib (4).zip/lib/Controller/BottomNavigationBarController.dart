import 'package:get/get.dart';

class BottomNavigationBarController extends GetxController {
  @override
  void onInit() async {
    super.onInit();
  }
}
