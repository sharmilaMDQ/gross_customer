import 'package:get/get.dart';

class VerifyNumberScreenController extends GetxController {
  @override
  void onInit() async {
    super.onInit();
  }
}
