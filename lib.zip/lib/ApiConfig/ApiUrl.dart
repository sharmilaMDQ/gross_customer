class ApiUrl {
 static const bool isProductionUrl = false;
  static const String appVersion = "1.0";
  static const int maxAuthRetry = 3;
 static const String baseUrl = isProductionUrl
      ? "https://mdqualityapps.in/API/gross_shop/development/"
      : "https://mdqualityapps.in/API/gross_shop/development/";
  static String login_token = "";
  static String login = "customer-signin";
  static String register = "customer-signup";
  static String editProfile = "update-customerprofile";
  static String favoriteScreen = "filter_nearby_products";
  static String homeScreen = "filter_nearby_products";
  static String addWishList = "add-wishlist";
  static String deleteWishList = "delete-wishlist";
  static String SelectProductScreen = "get_related_product";
  static String addcart = "add_cart_product";
  static String getcart = "get_cart_product";
  static String deletecart = "delete_cart_product";
  static String SearchProduct = "searchproducts";
 static  String forgotPassword = "customer-forgot-password";
 static  String getParticularCustomer = "get-customer";
 static  String getOfferslist = "get-offers";
 static  String getCustomerOrderlist = "get_customer_placed_orders";
 static  String getCustomerPlaceOrderList = "place_orders";
 static  String deleteCart = "delete-cart";
}
