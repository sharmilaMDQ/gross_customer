import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:dio/dio.dart' as dio;
import 'package:image_picker/image_picker.dart';
import '../ApiConfig/ApiUrl.dart';
import '../ApiConfig/HttpService.dart';
import '../Models/GetCustomerOrderLIstResponseModel.dart';
import '../Models/OffersListResponse.dart';
import '../Models/ParticularCustomerResponseModel.dart';
import '../Models/RegisterIdResponse.dart';
import '../Models/SearchProductsResponse.dart';
import '../Pojo/AddCartProductResponse.dart';
import '../Pojo/DeleteCartResponse.dart';
import '../Pojo/DisplaySelectedProductScreenResponse.dart';
import '../Pojo/FovouiteStoreScreenResponse.dart';
import '../Pojo/GetCartProductResponse.dart';
import '../Pojo/ProductHomeScreenResponse.dart';
import '../Pojo/LoginScreenResponse.dart';
import '../Pojo/RegisterResponse.dart';
import '../Pojo/SearchProductResponse.dart';
import '../utility/AppUtility.dart';
import 'package:http/http.dart' as http;

class ApiConnect extends GetConnect {
  // HttpService httpService = HttpService();

  @override
  onInit() async {
    // await httpService.init();
    super.onInit();
    super.allowAutoSignedCert = true;
    super.onInit();

    httpClient.addResponseModifier((request, response) {
      debugPrint("------------ AUTH ------------");
      debugPrint(
          "REQUEST METHOD: ${request.method} ; ENDPOINT:  ${request.url}");
      debugPrint("RESPONSE : ${response.bodyString}");
      return response;
    });
  }

  // Future<LoginResponse> LoginScreenres(Map<String, dynamic> payload) async {
  //   httpService.init();
  //   var Response = await httpService.request(
  //       url: ApiUrl.login, method: Method.POST, params: payload);
  //   if (Response is dio.Response) {
  //     if (Response.data == null) {
  //       throw Exception(AppUtility.connectivityMessage);
  //     }
  //     return LoginResponse.fromJson(Response.data);
  //   }
  //   return LoginResponse();
  // }


  Future<LoginResponse> LoginScreenres(Map<String, dynamic> payload) async {
    FormData formData = FormData(payload);
    var response = await post(ApiUrl.baseUrl + ApiUrl.login, formData);
    if (response.body == null) throw Exception(AppUtility.connectivityMessage);
    return LoginResponse.fromJson(response.body);
  }
 // Future<RegisterResponse> RegisterScreen(Map<String, dynamic> payload) async {
 //    FormData formData = FormData(payload);
 //    var response = await post(ApiUrl.baseUrl + ApiUrl.register, formData);
 //    if (response.body == null) throw Exception(AppUtility.connectivityMessage);
 //    return RegisterResponse.fromJson(response.body);
 //  }
  Future<RegisterCustomerIdResponse> registerUpload(
      Map<String, dynamic> payload, String endpoint) async {
    FormData formData = FormData(payload);
    var response = await post(ApiUrl.baseUrl + endpoint, formData);
    if (response.body == null) throw Exception(AppUtility.connectivityMessage);
    return RegisterCustomerIdResponse.fromJson(response.body);
  }

  Future<RegisterResponse> forgotPassword(
      Map<String, dynamic> payload) async {
    FormData formData = FormData(payload);
    var response = await post(
      ApiUrl.baseUrl + ApiUrl.forgotPassword,
      formData,
    );
    if (response.body == null) throw Exception(AppUtility.connectivityMessage);
    print("Status_Code ${response.statusCode}");
    print("body ${response.body}");
    return RegisterResponse.fromJson(response.body);
  }

  Future<RegisterCustomerIdResponse> imgRegisterCall(
      String url,
      XFile? imageFile,
      Map<String, String> payload,
      ) async {

    print("URL$url");
    var request =
    http.MultipartRequest('POST', Uri.parse(ApiUrl.baseUrl + url));

    if (imageFile != null) {
      var imageStream = http.ByteStream(imageFile.openRead());
      var imageLength = await imageFile.length();
      var multipartFile = http.MultipartFile(
          'customerImage', imageStream, imageLength,
          filename: imageFile.path.split('/').last);
      request.files.add(multipartFile);
    }
    request.fields.addAll(payload);
    // Send the request
    var response = await request.send();

    var responseBody = await response.stream.bytesToString();
    debugPrint("responseBody : ${responseBody}");

    var parsedResponse;

    try {
      parsedResponse = json.decode(responseBody) as Map<String, dynamic>;
    } catch (e) {
      return RegisterCustomerIdResponse();
    }
    debugPrint("url : ${url}");
    debugPrint("imageFile : ${parsedResponse}");

    var convertedResponse = RegisterCustomerIdResponse.fromJson(parsedResponse);
    print("Status_Code ${response.statusCode}");

    return convertedResponse;
  }
  Future<FavoriteScreenRes> favoriteScreen(Map<String, dynamic> payload) async {
    FormData formData = FormData(payload);
    Map<String, String> header = {
      'x-api-key': '655f636f6d6d657263655f6d6f62696c65',
    };
    var response = await post(ApiUrl.baseUrl + ApiUrl.favoriteScreen, formData ,headers:header );
    if (response.body == null) throw Exception(AppUtility.connectivityMessage);
    return FavoriteScreenRes.fromJson(response.body);
  }

  // Future<RegisterResponse> RegisterScreen(Map<String, dynamic> payload) async {
  //   httpService.init();
  //   var Response = await httpService.request(
  //       url: ApiUrl.register, method: Method.POST, params: payload);
  //   if (Response is dio.Response) {
  //     if (Response.data == null) {
  //       throw Exception(AppUtility.connectivityMessage);
  //     }
  //     return RegisterResponse.fromJson(Response.data);
  //   }
  //   return RegisterResponse();
  // }

  // Future<FavoriteScreenRes> favoriteScreen(Map<String, dynamic> payload) async {
  //   httpService.init();
  //   var Response = await httpService.request(
  //       url: ApiUrl.favoriteScreen, method: Method.POST, params: payload);
  //   if (Response is dio.Response) {
  //     if (Response.data == null) {
  //       throw Exception(AppUtility.connectivityMessage);
  //     }
  //     return FavoriteScreenRes.fromJson(Response.data);
  //   }
  //   return FavoriteScreenRes();
  // }

  // Future<ProductHomeResponse> HomeScreen(Map<String, dynamic> payload) async {
  //   httpService.init();
  //   var Response = await httpService.request(
  //       url: ApiUrl.homeScreen, method: Method.POST, params: payload);
  //
  //   if (Response is dio.Response) {
  //     if (Response.data == null) {
  //       throw Exception(AppUtility.connectivityMessage);
  //     }
  //     return ProductHomeResponse.fromJson(Response.data);
  //   }
  //   return ProductHomeResponse();
  // }

  Future<ProductHomeResponse> HomeScreen(Map<String, dynamic> payload
     ) async {
    Map<String, String> header = {
      'x-api-key': '655f636f6d6d657263655f6d6f62696c65',
    };
    FormData formData = FormData(payload);
    var response = await post(ApiUrl.baseUrl + ApiUrl.homeScreen ,formData ,headers: header
       );
    if (response.body == null) throw Exception(AppUtility.connectivityMessage);
    print("Status_Code ${response.statusCode}");
    print("body ${response.body}");
    return ProductHomeResponse.fromJson(response.body);

  }

  Future<AddCartResponse> AddWishList(Map<String, dynamic> payload
     ) async {
    Map<String, String> header = {
      'x-api-key': '655f636f6d6d657263655f6d6f62696c65',
    };
    FormData formData = FormData(payload);
    var response = await post(ApiUrl.baseUrl + ApiUrl.addWishList ,formData ,headers: header
       );
    if (response.body == null) throw Exception(AppUtility.connectivityMessage);
    print("Status_Code ${response.statusCode}");
    print("body ${response.body}");
    return AddCartResponse.fromJson(response.body);

  }
  Future<AddCartResponse> DeleteWishList(Map<String, dynamic> payload
     ) async {
    Map<String, String> header = {
      'x-api-key': '655f636f6d6d657263655f6d6f62696c65',
    };
    FormData formData = FormData(payload);
    var response = await post(ApiUrl.baseUrl + ApiUrl.deleteWishList ,formData ,headers: header
       );
    if (response.body == null) throw Exception(AppUtility.connectivityMessage);
    print("Status_Code ${response.statusCode}");
    print("body ${response.body}");
    return AddCartResponse.fromJson(response.body);

  }




  Future<ProductHomeResponse> DeleteCartAll(Map<String, dynamic> payload
     ) async {
    Map<String, String> header = {
      'x-api-key': '655f636f6d6d657263655f6d6f62696c65',
    };
    FormData formData = FormData(payload);
    var response = await post(ApiUrl.baseUrl + ApiUrl.deleteCart ,formData ,headers: header
       );
    if (response.body == null) throw Exception(AppUtility.connectivityMessage);
    print("Status_Code ${response.statusCode}");
    print("body ${response.body}");
    return ProductHomeResponse.fromJson(response.body);

  }
  Future<DisplaySelectedProductResponse> DisplaySelectScreen(
      Map<String, dynamic> payload) async {
    Map<String, String> header = {
      'x-api-key': '655f636f6d6d657263655f6d6f62696c65',
    };
    FormData formData = FormData(payload);
    var response = await post(ApiUrl.baseUrl + ApiUrl.SelectProductScreen, formData,
        headers: header);
    if (response.body == null) throw Exception(AppUtility.connectivityMessage);
    print("Status_Code ${response.statusCode}");
    print("body ${response.body}");
    return DisplaySelectedProductResponse.fromJson(response.body);

  }
  Future<GetCustomerResponseModel> GetCustomerOrderList(
      Map<String, dynamic> payload) async {
    Map<String, String> header = {
      'x-api-key': '655f636f6d6d657263655f6d6f62696c65',
    };
    FormData formData = FormData(payload);
    var response = await post(ApiUrl.baseUrl + ApiUrl.getCustomerOrderlist, formData,
        headers: header);
    if (response.body == null) throw Exception(AppUtility.connectivityMessage);
    print("Status_Code ${response.statusCode}");
    print("body ${response.body}");
    return GetCustomerResponseModel.fromJson(response.body);

  }
Future<AddCartResponse> AddCart(
      Map<String, dynamic> payload) async {
    Map<String, String> header = {
      'x-api-key': '655f636f6d6d657263655f6d6f62696c65',
    };
    FormData formData = FormData(payload);
    var response = await post(ApiUrl.baseUrl + ApiUrl.addcart, formData,
        headers: header);
    if (response.body == null) throw Exception(AppUtility.connectivityMessage);
    print("Status_Code ${response.statusCode}");
    print("body ${response.body}");
    return AddCartResponse.fromJson(response.body);

  }
Future<GetCartResponse> GetCart(
      Map<String, dynamic> payload) async {
    Map<String, String> header = {
      'x-api-key': '655f636f6d6d657263655f6d6f62696c65',
    };
    FormData formData = FormData(payload);
    var response = await post(ApiUrl.baseUrl + ApiUrl.getcart, formData,
        headers: header);
    if (response.body == null) throw Exception(AppUtility.connectivityMessage);
    print("Status_Code ${response.statusCode}");
    print("body ${response.body}");
    return GetCartResponse.fromJson(response.body);

  }

  Future<AddCartResponse> PlaceOrderList(
      Map<String, dynamic> payload) async {
    Map<String, String> header = {
      'x-api-key': '655f636f6d6d657263655f6d6f62696c65',
    };
    FormData formData = FormData(payload);
    var response = await post(ApiUrl.baseUrl + ApiUrl.getCustomerPlaceOrderList, formData,
        headers: header);
    if (response.body == null) throw Exception(AppUtility.connectivityMessage);
    print("Status_Code ${response.statusCode}");
    print("body ${response.body}");
    return AddCartResponse.fromJson(response.body);

  }
Future<OffersListResponse> GetOfferList() async {
  Map<String, String> header = {
    'x-api-key': '655f636f6d6d657263655f6d6f62696c65',
  };
    var response = await get(ApiUrl.baseUrl + ApiUrl.getOfferslist, headers: header);
    if (response.body == null) throw Exception(AppUtility.connectivityMessage);
    print("Status_Code ${response.statusCode}");
    print("body ${response.body}");
    return OffersListResponse.fromJson(response.body);

  }
  Future<DeleteCartResponse> DeleteCart(
      Map<String, dynamic> payload) async {
    Map<String, String> header = {
      'x-api-key': '655f636f6d6d657263655f6d6f62696c65',
    };
    FormData formData = FormData(payload);
    var response = await post(ApiUrl.baseUrl + ApiUrl.deletecart, formData,
        headers: header);
    if (response.body == null) throw Exception(AppUtility.connectivityMessage);
    print("Status_Code ${response.statusCode}");
    print("body ${response.body}");
    return DeleteCartResponse.fromJson(response.body);

  }

  // Future<DisplaySelectedProductResponse> DisplaySelectScreen(
  //     Map<String, dynamic> payload) async {
  //   httpService.init();
  //   var Response = await httpService.request(
  //       url: ApiUrl.SelectProductScreen, method: Method.POST, params: payload);
  //
  //   if (Response is dio.Response) {
  //     if (Response.data == null) {
  //       throw Exception(AppUtility.connectivityMessage);
  //     }
  //     return DisplaySelectedProductResponse.fromJson(Response.data);
  //   }
  //   return DisplaySelectedProductResponse();
  // }

  // Future<AddCartResponse> AddCart(Map<String, dynamic> payload) async {
  //   httpService.init();
  //   var Response = await httpService.request(
  //       url: ApiUrl.addcart, method: Method.POST, params: payload);
  //
  //   if (Response is dio.Response) {
  //     if (Response.data == null) {
  //       throw Exception(AppUtility.connectivityMessage);
  //     }
  //     return AddCartResponse.fromJson(Response.data);
  //   }
  //   return AddCartResponse();
  // }

  // Future<GetCartResponse> GetCart(Map<String, dynamic> payload) async {
  //   httpService.init();
  //   var Response = await httpService.request(
  //       url: ApiUrl.getcart, method: Method.POST, params: payload);
  //
  //   if (Response is dio.Response) {
  //     if (Response.data == null) {
  //       throw Exception(AppUtility.connectivityMessage);
  //     }
  //     return GetCartResponse.fromJson(Response.data);
  //   }
  //   return GetCartResponse();
  // }

  // Future<DeleteCartResponse> DeleteCart(Map<String, dynamic> payload) async {
  //   httpService.init();
  //   var Response = await httpService.request(
  //       url: ApiUrl.deletecart, method: Method.POST, params: payload);
  //
  //   if (Response is dio.Response) {
  //     if (Response.data == null) {
  //       throw Exception(AppUtility.connectivityMessage);
  //     }
  //     return DeleteCartResponse.fromJson(Response.data);
  //   }
  //   return DeleteCartResponse();
  // }
  //
  // Future<ProductHomeResponse> SearchProduct(
  //     Map<String, dynamic> payload) async {
  //   httpService.init();
  //   var Response = await httpService.request(
  //       url: ApiUrl.SearchProduct, method: Method.POST, params: payload);
  //   if (Response is dio.Response) {
  //     if (Response.data == null) {
  //       throw Exception(AppUtility.connectivityMessage);
  //     }
  //     return ProductHomeResponse.fromJson(Response.data);
  //   }
  //   return ProductHomeResponse();
  // }


  Future<SearchProductsResponse> SearchProduct(
      Map<String, dynamic> payload) async {
    Map<String, String> header = {
      'x-api-key': '655f636f6d6d657263655f6d6f62696c65'
    };
    FormData formData = FormData(payload);
    var response = await post(ApiUrl.baseUrl + ApiUrl.SearchProduct, formData,
        headers: header);
    if (response.body == null) throw Exception(AppUtility.connectivityMessage);
    print("Status_Code ${response.statusCode}");
    print("body ${response.body}");
    return SearchProductsResponse.fromJson(response.body);

  }

  Future<ParticularCustomerResponse> GetParticularCustomer(
      Map<String, dynamic> payload) async {
    Map<String, String> header = {
      'x-api-key': '655f636f6d6d657263655f6d6f62696c65'
    };
    FormData formData = FormData(payload);
    var response = await post(
      ApiUrl.baseUrl + ApiUrl.getParticularCustomer,
      formData, headers: header
    );
    if (response.body == null) throw Exception(AppUtility.connectivityMessage);
    print("Status_Code ${response.statusCode}");
    print("body ${response.body}");
    return ParticularCustomerResponse.fromJson(response.body);
  }
}