import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/svg.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:google_fonts/google_fonts.dart';
import 'AppTheme.dart';

class ProductDisplayCommonComponent extends StatefulWidget {
  final String productname;
  final String shopName;
  final String productQty;
  final String productCategory;
  final String productprice;
  final String productimage;
  final bool isFavaurite;
  final VoidCallback? onTap;



  ProductDisplayCommonComponent({
    Key? key,
    required this.productimage,
    required this.productQty,
    required this.productprice,
    required this.shopName,
    required this.productname,
    required this.productCategory,
    required this.onTap,
    required this.isFavaurite,

  }) : super(key: key);

  @override
  _ProductDisplayCommonComponentState createState() =>
      _ProductDisplayCommonComponentState();
}

class _ProductDisplayCommonComponentState
    extends State<ProductDisplayCommonComponent> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          color: Colors.white,
          height: MediaQuery.of(context).size.height * 0.3,
          padding: EdgeInsets.only(right: 3, left: 3),
          child: Stack(
            children: [
              Positioned(
                child: Container(
                  height: MediaQuery.of(context).size.height * 0.15,
                  width: MediaQuery.of(context).size.width * 0.4,
                  child: Stack(
                    children: [
                      Center(
                          child: Image.network(
                        '${widget.productimage}',
                        height: MediaQuery.of(context).size.height * 0.15,
                        width: MediaQuery.of(context).size.width * 0.40,
                        fit: BoxFit.fill,
                      )),
                      Positioned(
                        top:0,
                        left: 120,
                        child: InkWell(
                            onTap: widget.onTap,
                            child: widget.isFavaurite == true
                                ? Icon(
                              Icons.favorite,
                              size: 25,
                              color: Colors.redAccent,
                            )
                                : Icon(
                              Icons.favorite_border,
                              size: 25,
                              color: Colors.redAccent,
                            )),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                top: 130,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text('${widget.productname}',
                        style: GoogleFonts.poppins(
                          color: Colors.black,
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        )),
                  ],
                ),
              ),
              Positioned(
                top: 160,
                child: Container(
                  alignment: Alignment.centerLeft,
                  child: Text('${widget.shopName}',
                      style: GoogleFonts.poppins(
                        color: Color(0xFF475269).withOpacity(0.7),
                        fontSize: 12,
                        fontWeight: FontWeight.w400,
                      )),
                ),
              ),
              Positioned(
                top: 180,
                child: Text('${widget.productQty}',
                    style: GoogleFonts.poppins(
                      color: Colors.black,
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                    )),
              ),
              Positioned(
                top: 180,
                left: 115,
                child: Container(
                  padding: EdgeInsets.all(3),
                  decoration: BoxDecoration(
                    color: Colors.orangeAccent,
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: SvgPicture.asset(
                    'assets/icons/shoppingBag.svg',
                    height: 20,
                    color: Colors.white,
                  ),
                ),
              ),
              Positioned(
                top: 210,
                child: Text('₹ ${widget.productprice}',
                    style: GoogleFonts.poppins(
                      color: AppTheme.Buttoncolor,
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                    )),
              )
            ],
          ),
        )
      ],
    );

    //   Stack(
    //   children: [
    //     Column(
    //       children: [
    //         Container(
    //           color: Colors.white,
    //           height: MediaQuery.of(context).size.height * 0.3,
    //           padding: EdgeInsets.only(right: 3, left: 3),
    //           child: Column(
    //             mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    //             children: [
    //               Positioned(top: 30, child: Text("Text")),
    //               Container(
    //                 height: MediaQuery.of(context).size.height * 0.15,
    //                 width: MediaQuery.of(context).size.width * 0.50,
    //                 child: Center(
    //                     child: Image.network(
    //                   '${widget.productimage}',
    //                   height: MediaQuery.of(context).size.height * 0.15,
    //                   width: MediaQuery.of(context).size.width * 0.50,
    //                   fit: BoxFit.fill,
    //                 )),
    //               ),
    //               Row(
    //                 mainAxisAlignment: MainAxisAlignment.start,
    //                 children: [
    //                   Text('${widget.productname}',
    //                       style: GoogleFonts.poppins(
    //                         color: Colors.black,
    //                         fontSize: 14,
    //                         fontWeight: FontWeight.w600,
    //                       )),
    //                 ],
    //               ),
    //               // SizedBox(
    //               //   height: MediaQuery.of(context).size.height * 0.1,
    //               // ),
    //               Row(
    //                 mainAxisAlignment: MainAxisAlignment.start,
    //                 children: [
    //                   Container(
    //                     alignment: Alignment.centerLeft,
    //                     child: Text('${widget.shopName}',
    //                         style: GoogleFonts.poppins(
    //                           color: Color(0xFF475269).withOpacity(0.7),
    //                           fontSize: 12,
    //                           fontWeight: FontWeight.w400,
    //                         )),
    //                   ),
    //                 ],
    //               ),
    //
    //               Row(
    //                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
    //                 children: [
    //                   Text('${widget.productQty}',
    //                       style: GoogleFonts.poppins(
    //                         color: Colors.black,
    //                         fontSize: 14,
    //                         fontWeight: FontWeight.w400,
    //                       )),
    //                   Container(
    //                     padding: EdgeInsets.all(3),
    //                     decoration: BoxDecoration(
    //                       color: Colors.orangeAccent,
    //                       borderRadius: BorderRadius.circular(5),
    //                     ),
    //                     child: SvgPicture.asset(
    //                       'assets/icons/shoppingBag.svg',
    //                       height: 20,
    //                       color: Colors.white,
    //                     ),
    //                   ),
    //                 ],
    //               ),
    //
    //               Row(
    //                 crossAxisAlignment: CrossAxisAlignment.center,
    //                 children: [
    //                   Text('₹ ${widget.productprice}',
    //                       style: GoogleFonts.poppins(
    //                         color: AppTheme.Buttoncolor,
    //                         fontSize: 18,
    //                         fontWeight: FontWeight.w600,
    //                       )),
    //                 ],
    //               ),
    //             ],
    //           ),
    //         ),
    //       ],
    //     ),
    //   ],
    // );
  }
}
