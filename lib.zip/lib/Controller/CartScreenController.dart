import 'dart:convert';
import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get/get_rx/get_rx.dart';
import 'package:grosshop/utility/AppExtension.dart';
import 'package:provider/provider.dart';

import '../Apiconnect/ApiConnect.dart';
import '../Components/ProductDetails.dart';
import '../Forms/AppSnackBar.dart';
import '../Models/PlaceOrdeItemResponse.dart';
import '../Pojo/DeleteCartResponse.dart';
import '../Pojo/GetCartProductResponse.dart';
import '../Provider/ProductProvider.dart';
import '../utility/AppPreference.dart';
import '../utility/BottomNavigationBar.dart';
import '../utility/keys.dart';

class CartScreenController extends GetxController {
  RxInt selectedTabIndex = 0.obs;
  late RxList<CartData> CartProdct = RxList();
  late RxList<CartData> CartProdctList = RxList();
  late RxList<PlaceOrderItemsResponse> placeOrderItems = RxList();

  // DeleteCartResponse deletecartResponse = DeleteCartResponse();
  TextEditingController pickUptimeController = TextEditingController();
  TextEditingController addressController = TextEditingController();
  TextEditingController mobileNumberController = TextEditingController();
  TextEditingController productCategoryController = TextEditingController();
  RxString productCategoryDropdown = RxString('Enter Product Category'.tr);
  final selectedCategory = ''.obs;
  final ApiConnect _connect = Get.put(ApiConnect());
  bool isSelectCall = false;
  RxInt count = RxInt(0); // Observable integer
  late ProductProvider userDataProvider;
  RxList<bool> onClickList = RxList();
  RxBool isClicked = RxBool(false);
  RxList<bool> onClickCounterList = RxList();
  RxBool isLoading = RxBool(false);
  int index = 0;
  RxString pickupMethods = RxString("");
  RxString UpdatePrice = RxString("");
  RxString UpdateTotalPrice = RxString("0");
  RxList<RxInt> counter = RxList<RxInt>([RxInt(1)]);
  int selectedIndex = 0;
  RxInt selectedIndexOne = RxInt(0);
  final List<String> categories = [
    'Cash On Delivery',
    'Net Banking',
    'Upi Payment',
  ];

// RxList <RxString> UpdatePrice =  RxList<RxString> ([RxString("")]);
  paymentProcess() async {
    for (int i = 0; i < onClickList.length; i++) {
      if (onClickList[i] == true) {
        isClicked.value = true;
        selectedIndex = i;
        break;
      }
    }

    if (isClicked.value == false) {
      Fluttertoast.showToast(
        msg: "Select the Time Slot",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: Colors.black,
        textColor: Colors.white,
      );
      return;
    }
  }

  void incrementCounter(int index) {
    isLoading.value = true;
    if (index >= 0 && index < counter.length) {
      counter[index].value++;
    }
    int price =
        int.tryParse(CartProdct[index].productPriceDuplicate ?? '0') ?? 0;
    int result = price * counter[index].value;
    UpdatePrice.value = result.toString();
    CartProdct[index].productPrice = UpdatePrice.value;

    log(json.encode(CartProdct));

    isLoading.value = false;
  }

  void updatePrice(int index) {
    if (index >= 0 && index < CartProdct.length && index < counter.length) {}
  }

  void decrementCounter(int index) {
    isLoading.value = true;

    if (index >= 0 && index < counter.length && counter[index].value > 1) {
      counter[index].value--;
    }
    int price =
        int.tryParse(CartProdct[index].productPriceDuplicate ?? '0') ?? 0;
    int result = price * counter[index].value;
    UpdatePrice.value = result.toString();
    CartProdct[index].productPrice = UpdatePrice.value;

    log(json.encode(CartProdct));

    isLoading.value = false;
  }

  @override
  void onInit() async {
    super.onInit();
    userDataProvider =
        Provider.of<ProductProvider>(Get.context!, listen: false);
    addressController.text = userDataProvider.getLocation.toString();
  }

  void increment() {
    count++;
  }

  GetCartApi() async {
    Map<String, dynamic> payload = {
      'userId': AppPreference().UserId,
      'productId': "",
    };
    print(payload);
    isLoading.value = true;
    var response = await _connect.GetCart(payload);

    print("CartScreen${response.toJson()}");
    onClickList.clear();
    counter.clear();
    if (!response.error!) {
      print('check cart api');
      CartProdct.value = response.data!;
      debugPrint("getAttendanceList: ${response.toJson()}");
      for (int i = 0; i < response.data!.length; i++) {
        counter.add(RxInt(1));
        update();
      }
    } else {

    }
    isLoading.value = false;
  }

  GetCartPlaceItemsApi(context) async {
    List<Map<String, dynamic>> ballonMakingJsonList =
        placeOrderItems.map((item) => item.toJson()).toList();
    String BallonMarking = jsonEncode(ballonMakingJsonList);

    placeOrderItems.clear();
    for (int i = 0; i < CartProdct.length; i++) {
      PlaceOrderItemsResponse placeItems = PlaceOrderItemsResponse();
      placeItems.productName = CartProdct[index].productName.toString();
      placeItems.productId = CartProdct[index].id.toString();
      placeItems.productPrice = CartProdct[index].productPrice.toString();
      placeItems.productQty = CartProdct[index].productQty.toString();
      placeItems.orderedQty = counter[index].toString();
      placeOrderItems.add(placeItems);


      String productPrice = CartProdct[i].productPrice.toString();
      String updatePrice = UpdateTotalPrice.value;
      int num1 = int.parse(productPrice);
      int num2 = int.parse(updatePrice);
      int result = num1 + num2;
      UpdateTotalPrice.value = result.toString();
      print( " Total price : ${UpdateTotalPrice.value}");
    }
    print("placeOrderItems ${json.encode(placeOrderItems)}");

    Map<String, dynamic> payload = {
      "items": json.encode(placeOrderItems),
      "sellerId": CartProdct[0].sellerId,
      "customerId": AppPreference().UserId.toString(),
      "firstPromoOffer": "",
      "totalOrderCost": UpdateTotalPrice.value,
      "paymentOption": productCategoryController.text,
      "pickupTime":  AppPreference().pickup == "PickUp" ? pickUptimeController.text : "0",
      "deliveryFee": "30",
      "deliveryOption": pickupMethods.value,
      "deliveryTime": "",
      "deliveryMobileNo": mobileNumberController.text
    };
    print("PlaceOrderpayload${payload}");
    isLoading.value = true;
    var response = await _connect.PlaceOrderList(payload);
    isLoading.value = false;

    print("Response${response.toJson()}");
    if (!response.error!) {
      Fluttertoast.showToast(
        msg: response.message!,
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: Colors.black,
        textColor: Colors.white,
      );
      pickUptimeController.text = "";
      UpdateTotalPrice.value.isEmpty;
      pickupMethods.value.isEmpty;
      mobileNumberController.text = "";
      Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => navigateBar()),
      );
    }
  }

  DeleteCartApi() async {
    Map<String, dynamic> payload = {'userId': AppPreference().UserId};
    print(payload);
    print(CartProdct.value[index].id);
    var response = await _connect.DeleteCart(payload);
    print("Delete Api Called ${response.toJson()}");
    if (!response.error!) {
      Fluttertoast.showToast(
        msg: response.message!,
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: Colors.black,
        textColor: Colors.white,
      );
      print('check Delete');
      CartProdct.clear();
      update();
    } else {
      AppSnackBar.error(message: response.message!);
    }
  }
}
