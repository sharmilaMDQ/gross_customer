import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import '../Apiconnect/ApiConnect.dart';
import '../Forms/AppSnackBar.dart';
import '../Pageroutes/App_routes.dart';
import '../utility/AppPreference.dart';

class LoginScreenController extends GetxController {
  RxBool isVisible = false.obs;
  RxBool isLoading = RxBool(false);
  TextEditingController usercontroller = TextEditingController();
  TextEditingController passwordcontroller = TextEditingController();
  RxBool isPhoneNoError = RxBool(false);
  RxBool isPasswordError = RxBool(false);
  final ApiConnect _connect = Get.put(ApiConnect());

  void toggleVisibility() {
    isVisible.value = !isVisible.value;
  }

  // void openFacebookUrl() async {
  //   const facebookUrl = 'https://www.facebook.com/valiancetechnology';
  //
  //   if (await canLaunch(facebookUrl)) {
  //     await launch(facebookUrl);
  //   } else {
  //     // Handle the case if the URL can't be launched
  //     print('Could not launch Facebook URL');
  //   }
  // }

  @override
  void onInit() async {
    super.onInit();
  }

  loginApi() async {
    isPhoneNoError.value = false;
    isPasswordError.value = false;
    // try {
    if (usercontroller.value.text.length != 10) {
      isPhoneNoError.value = true;
      Fluttertoast.showToast(
        msg: "Please Enter Mobile Number In Correctly!",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: Colors.black,
        textColor: Colors.white,
      );
      return;
    }
    if (passwordcontroller.value.text.isEmpty) {
      isPasswordError.value = true;
      Fluttertoast.showToast(
        msg: "Please enter Your Password!",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: Colors.black,
        textColor: Colors.white,
      );
      return;
    }
    Map<String, dynamic> payload = {
      'customerMobile': usercontroller.value.text.toString(),
      'customerPassword': passwordcontroller.value.text.toString(),
    };
    print("LoginPayload${payload}");
    isLoading.value = true;
    var response = await _connect.LoginScreenres(payload);
    isLoading.value = false;
    print('loginResponse ${response.toJson()}');
    if (!response.error!) {
      Fluttertoast.showToast(
        msg: response.message!,
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: Colors.black,
        textColor: Colors.white,
      );
      AppPreference().updateUserId(response.data!.customerId!.toString());
      Get.toNamed(AppRoutes.login.toName);
      update();
      usercontroller.text = "";
      passwordcontroller.text = "";
    } else {
      Fluttertoast.showToast(
        msg: response.message!,
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: Colors.red,
        textColor: Colors.white,
      );
    }

    isLoading.value = false;
  }
}
