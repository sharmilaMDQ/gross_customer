import 'package:get/get_navigation/src/routes/get_route.dart';
import 'package:grosshop/Binding/EditProfileBinding.dart';
import 'package:grosshop/Binding/GetCurrentLocationBinding.dart';
import 'package:grosshop/Binding/ProductHomeScreenBinding.dart';
import 'package:grosshop/UI/HomeScreen/ProductHomeScreen.dart';
import '../Binding/DisplaySelectedScreenBinding.dart';
import '../Binding/FavouriteStoreScreenBinding.dart';
import '../Binding/LoginScreenBinding.dart';
import '../Binding/VerifyNumberScreenBinding.dart';

import '../UI/SplashScreens/FavouriteStoreScreen.dart';
import '../UI/Location/GetCurrentLocation.dart';
import '../UI/HomeScreen/DisplaySelectedProduct.dart';
import '../UI/LoginScreen/LoginScreen.dart';
import '../UI/SettingsScreen/EditProfile.dart';
import '../UI/LoginScreen/VerifyNumberScreen.dart';
import 'App_routes.dart';

class AppPages {
  static var list = [
    GetPage(
        name: AppRoutes.root.toName,
        page: () => LoginScreen(),
        binding: LoginScreenBinding()),
    GetPage(
        name: AppRoutes.home.toName,
        page: () => ProductHomeScreen(),
        binding: ProductHomeScreenBinding()),
    GetPage(
        name: AppRoutes.register.toName,
        page: () => VerifyNumberScreen(),
        binding: VerifyNumberScreenBinding()),
    GetPage(
        name: AppRoutes.login.toName,
        page: () => FavouriteStoreScreen(),
        binding: FavouriteStoreScreenBinding()),
    GetPage(
        name: AppRoutes.producthomescreen.toName,
        page: () => DisplaySelectedProduct(),
        binding: DisplaySelectedScreenBinding()),
    GetPage(
        name: AppRoutes.editProfile.toName,
        page: () => EditProfileScreen(),
        binding: EditProfileScreenBinding()),
    GetPage(
        name: AppRoutes.getcurrentLocationMap.toName,
        page: () => MapScreen(),
        binding: GetCurrentLocationScreenBinding()),
  ];
}
