class GetCartResponse {
  String? message;
  bool? error;
  List<CartData>? data;

  GetCartResponse({this.message, this.error, this.data});

  GetCartResponse.fromJson(Map<String, dynamic> json) {
    message = json['message'];
    error = json['error'];
    if (json['data'] != null) {
      data = <CartData>[];
      json['data'].forEach((v) {
        data!.add(new CartData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['message'] = this.message;
    data['error'] = this.error;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}


class CartData {
  int? id;
  int? sellerId;
  String? productName;
  String? productQty;
  String? productPrice;
  String? productPriceDuplicate;
  String? productImage;
  String? productDescription;

  CartData(
      {this.id,
      this.sellerId,
        this.productName,
        this.productQty,
        this.productPriceDuplicate,
        this.productPrice,
        this.productImage,
        this.productDescription});

  CartData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    sellerId = json['sellerId'];
    productName = json['product_name'];
    productQty = json['product_qty'];
    productPrice = json['product_price'];
    productPriceDuplicate = json['product_price'];
    productImage = json['product_image'];
    productDescription = json['product_description'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['sellerId'] = this.sellerId;
    data['product_name'] = this.productName;
    data['product_qty'] = this.productQty;
    data['product_price'] = this.productPrice;
    data['product_image'] = this.productImage;
    data['product_description'] = this.productDescription;
    data['productPriceDuplicate'] = this.productPriceDuplicate;
    return data;
  }
}
