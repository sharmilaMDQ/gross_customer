import 'package:flutter/cupertino.dart';

import '../Models/GetCustomerOrderLIstResponseModel.dart';
import '../Pojo/DisplaySelectedProductScreenResponse.dart';

import '../Pojo/ProductHomeScreenResponse.dart';

class ProductProvider extends ChangeNotifier {
  Data? product;
  List<Data>? productData;
  Data? searchproduct;
  GetCustomerResponseModelData? customerOrderList;


  SelectedProductData? selectedproduct;
  String? location;
  String? latitude;
  String? longitude;

  String? get getLocation => location;
  String? get getLongitude => longitude;
  String? get getLatitude => latitude;

  Data? get products => product;
  List<Data>? get productDatas => productData;

  Data? get searchproducts => searchproduct;

  SelectedProductData? get selectedproducts => selectedproduct;
  GetCustomerResponseModelData? get getCustomerOrderLIst => customerOrderList;

  void SetProduct(Data? data) {
    product = data;
    notifyListeners();
  }
 void SetCustomerOrderList(GetCustomerResponseModelData? data) {
   customerOrderList = data;
    notifyListeners();
  }

  void SetProductList(List<Data>? data) {
    productData = data;
    notifyListeners();
  }

  void SetSearchProduct(Data? data) {
    searchproduct = data;
    notifyListeners();
  }

  void SetSelectedProduct(SelectedProductData? data) {
    selectedproduct = data;
    notifyListeners();
  }

  void SetSelectedLocation(String? data) {
    location = data;
    notifyListeners();
  }

  void setLongitude(String? data) {
    longitude = data;
    notifyListeners();
  }

  void setLatitude(String? data) {
    latitude = data;
    notifyListeners();
  }
}
