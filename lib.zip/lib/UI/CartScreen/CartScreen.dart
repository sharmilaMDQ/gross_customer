import 'dart:convert';
import 'dart:developer';

import 'package:date_format/date_format.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_time_picker_spinner/flutter_time_picker_spinner.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:grosshop/utility/AppPreference.dart';
import '../../Components/AppTheme.dart';
import '../../Components/CartCommonComponent.dart';
import '../../Components/Forms.dart';
import '../../Controller/CartScreenController.dart';
import '../../Forms/AppSnackBar.dart';

import '../../Models/PlaceOrdeItemResponse.dart';
import '../../Pageroutes/App_routes.dart';
import '../PaymentScreens/PaymentDetailScreen.dart';

class CartScreen extends GetView<CartScreenController> {
  CartScreen({Key? key}) : super(key: key);

  bool isSelected = false;

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.height;
    CartScreenController Controller = Get.put(CartScreenController());
    WidgetsBinding.instance?.addPostFrameCallback((_) {
      controller.GetCartApi();
    });
    return GetBuilder<CartScreenController>(
      init: CartScreenController(),
      builder: (controller) {
        return Theme(
          data: Theme.of(context).copyWith(
            dividerTheme: const DividerThemeData(
              color: Colors.transparent,
            ),
          ),
          child: Scaffold(
            persistentFooterButtons: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Center(
                  child: Button(
                    widthFactor: 0.8,
                    heightFactor: 0.06,
                    onPressed: () {

                      // for (int i = 0;
                      // i < controller.onClickList.length;
                      // i++) {
                      //   if (controller.onClickList[i] == true) {
                      //     controller.isClicked.value = true;
                      //     showDialog(
                      //       context: context,
                      //       builder: (BuildContext context) {
                      //         return DefaultTabController(
                      //           length: 2,
                      //           child: AlertDialog(
                      //             shape: RoundedRectangleBorder(
                      //               borderRadius: BorderRadius.circular(15),
                      //             ),
                      //             content: SingleChildScrollView(
                      //               child: Column(
                      //                 children: [
                      //                   SizedBox(height: 20),
                      //                   Row(
                      //                     mainAxisAlignment:
                      //                     MainAxisAlignment.spaceBetween,
                      //                     children: [
                      //                       Text(
                      //                         'Cart Total',
                      //                         style: GoogleFonts.poppins(
                      //                           color: Colors.black,
                      //                           fontSize: 18,
                      //                           fontWeight: FontWeight.bold,
                      //                         ),
                      //                       ),
                      //                       Text(
                      //                         controller.UpdateTotalPrice
                      //                             .toString(),
                      //                         style: GoogleFonts.poppins(
                      //                           color: Colors.black,
                      //                           fontSize: 18,
                      //                           fontWeight: FontWeight.w500,
                      //                         ),
                      //                       ),
                      //                     ],
                      //                   ),
                      //                   SizedBox(height: 15),
                      //                   Row(
                      //                     children: [
                      //                       Text(
                      //                         '9000 Young Street store',
                      //                         style: GoogleFonts.poppins(
                      //                           color: Colors.black87,
                      //                           fontSize: 18,
                      //                           fontWeight: FontWeight.w700,
                      //                         ),
                      //                       ),
                      //                     ],
                      //                   ),
                      //                   SizedBox(height: 15),
                      //                   Container(
                      //                     height: 400,
                      //                     width: MediaQuery.of(context).size.width,
                      //                     child: SingleChildScrollView(
                      //                       child: Column(
                      //                         children: [
                      //                           SizedBox(
                      //                             height: 45,
                      //                             child: Container(
                      //                               // decoration:
                      //                               // BoxDecoration(
                      //                               //   color: isSelected
                      //                               //       ? AppTheme
                      //                               //       .Buttoncolor
                      //                               //       : AppTheme
                      //                               //       .BorderColor,
                      //                               //   borderRadius:
                      //                               //   BorderRadius
                      //                               //       .circular(
                      //                               //       20),
                      //                               //   border:
                      //                               //   Border.all(
                      //                               //     color: Colors
                      //                               //         .orange,
                      //                               //   ),
                      //                               // ),
                      //                               child: TabBar(
                      //                                 unselectedLabelColor:
                      //                                 Colors.black,
                      //                                 indicatorSize:
                      //                                 TabBarIndicatorSize.tab,
                      //                                 indicator: BoxDecoration(
                      //                                     gradient: LinearGradient(
                      //                                         colors: [
                      //                                           AppTheme.Buttoncolor,
                      //                                           AppTheme.lightGreen
                      //                                         ]),
                      //                                     borderRadius:
                      //                                     BorderRadius.circular(
                      //                                         10),
                      //                                     color: Colors.redAccent),
                      //                                 labelColor: Colors.white,
                      //                                 // unselectedLabelColor:
                      //                                 // Colors
                      //                                 //     .black87,
                      //                                 // indicator:
                      //                                 // BoxDecoration(
                      //                                 //   color: Colors
                      //                                 //       .blue,
                      //                                 //   borderRadius:
                      //                                 //   BorderRadius
                      //                                 //       .circular(
                      //                                 //       5),
                      //                                 // ),
                      //                                 labelStyle: GoogleFonts.poppins(
                      //                                   color: Colors.white,
                      //                                   fontSize: 14,
                      //                                   fontWeight: FontWeight.w400,
                      //                                 ),
                      //                                 tabs: [
                      //                                   Tab(
                      //                                     text: 'Pickup',
                      //                                   ),
                      //                                   Tab(
                      //                                     text: 'Delivery',
                      //                                   ),
                      //                                 ],
                      //                               ),
                      //                             ),
                      //                           ),
                      //                           SizedBox(height: 15),
                      //                           Container(
                      //                             height: 350,
                      //                             child: TabBarView(
                      //                               children: [
                      //                                 Container(
                      //                                   height: 300,
                      //                                   child: SingleChildScrollView(
                      //                                     child: Column(
                      //                                       children: [
                      //                                         // Padding(
                      //                                         //   padding: EdgeInsets.symmetric(
                      //                                         //     horizontal: 10,
                      //                                         //   ),
                      //                                         //   child: TextInput1(
                      //                                         //
                      //                                         //     label: "",
                      //                                         //     onPressed: () {
                      //                                         //       showBottomTimePicker(
                      //                                         //           context, controller.timeOfBirthController);
                      //                                         //     },
                      //                                         //
                      //                                         //     controller: controller.timeOfBirthController,
                      //                                         //     textInputType: TextInputType.number,
                      //                                         //     textColor: Color(0xCC252525),
                      //                                         //     hintText: "Enter Pick up Time",
                      //                                         //     onTextChange: (String) {},
                      //                                         //     sufficIcon: Icon(Icons.access_time,size: 20, color: AppTheme.Buttoncolor,),
                      //                                         //   ),
                      //                                         // ),
                      //
                      //                                         Container(
                      //                                           height: 50,
                      //                                           width: MediaQuery.of(
                      //                                               context)
                      //                                               .size
                      //                                               .width *
                      //                                               0.9,
                      //                                           child: TextFormField(
                      //                                             onTap: () {
                      //                                               showBottomTimePicker(
                      //                                                   context,
                      //                                                   controller
                      //                                                       .pickUptimeController);
                      //                                             },
                      //                                             readOnly: true,
                      //                                             controller: controller
                      //                                                 .pickUptimeController,
                      //                                             decoration:
                      //                                             InputDecoration(
                      //                                                 border:
                      //                                                 OutlineInputBorder(),
                      //                                                 enabledBorder:
                      //                                                 OutlineInputBorder(
                      //                                                   borderSide:
                      //                                                   BorderSide(
                      //                                                       color:
                      //                                                       AppTheme.Buttoncolor),
                      //                                                   borderRadius:
                      //                                                   BorderRadius.circular(
                      //                                                       10),
                      //                                                 ),
                      //                                                 focusedBorder:
                      //                                                 OutlineInputBorder(
                      //                                                   borderSide:
                      //                                                   BorderSide(
                      //                                                       color:
                      //                                                       AppTheme.Buttoncolor),
                      //                                                   borderRadius:
                      //                                                   BorderRadius.circular(
                      //                                                       10),
                      //                                                 ),
                      //                                                 hintText:
                      //                                                 'Choose a pick time',
                      //                                                 hintStyle:
                      //                                                 GoogleFonts
                      //                                                     .poppins(
                      //                                                   color: Colors
                      //                                                       .black,
                      //                                                   fontSize:
                      //                                                   12,
                      //                                                   fontWeight:
                      //                                                   FontWeight
                      //                                                       .w400,
                      //                                                 ),
                      //                                                 suffixIcon:
                      //                                                 Icon(
                      //                                                   Icons
                      //                                                       .access_time,
                      //                                                   size: 20,
                      //                                                   color: AppTheme
                      //                                                       .Buttoncolor,
                      //                                                 )),
                      //                                           ),
                      //                                         ),
                      //                                         SizedBox(
                      //                                           height: 15,
                      //                                         ),
                      //                                         Center(
                      //                                           child: Button(
                      //                                             widthFactor: 0.9,
                      //                                             heightFactor: 0.06,
                      //                                             onPressed: () {
                      //                                               //Get.back();
                      //                                               // PaymentDetails(
                      //                                               //     context);
                      //                                               controller.pickupMethods.value == "PickUp";
                      //                                               controller.GetCartPlaceItemsApi();
                      //                                               // Navigator.push(
                      //                                               //     context,
                      //                                               //     MaterialPageRoute(
                      //                                               //         builder:
                      //                                               //             (context) =>
                      //                                               //                 PaymentDetailScreen()));
                      //                                               //  PaymentDetails();
                      //                                             },
                      //                                             child: Text(
                      //                                               'Checkout',
                      //                                               style: GoogleFonts
                      //                                                   .poppins(
                      //                                                 color:
                      //                                                 Colors.white,
                      //                                                 fontSize: 18,
                      //                                                 fontWeight:
                      //                                                 FontWeight
                      //                                                     .w400,
                      //                                               ),
                      //                                             ),
                      //                                           ),
                      //                                         ),
                      //                                       ],
                      //                                     ),
                      //                                   ),
                      //                                 ),
                      //                                 Container(
                      //                                   height: 300,
                      //                                   child: SingleChildScrollView(
                      //                                       child: Column(
                      //                                         children: [
                      //                                           Container(
                      //                                             height: 50,
                      //                                             width:
                      //                                             MediaQuery.of(context)
                      //                                                 .size
                      //                                                 .width *
                      //                                                 0.9,
                      //                                             child: TextFormField(
                      //                                               readOnly: true,
                      //                                               controller: controller
                      //                                                   .addressController,
                      //                                               onTap: () async {
                      //                                                 // var result = await Get
                      //                                                 //     .toNamed(AppRoutes
                      //                                                 //         .getcurrentLocationMap
                      //                                                 //         .toName);
                      //                                                 // if (result != null) {
                      //                                                 //   controller
                      //                                                 //           .addressController
                      //                                                 //           .text =
                      //                                                 //       controller
                      //                                                 //           .userDataProvider
                      //                                                 //           .getLocation
                      //                                                 //           .toString();
                      //                                                 // }
                      //                                               },
                      //                                               decoration:
                      //                                               InputDecoration(
                      //                                                   border:
                      //                                                   OutlineInputBorder(),
                      //                                                   enabledBorder:
                      //                                                   OutlineInputBorder(
                      //                                                     borderSide:
                      //                                                     BorderSide(
                      //                                                         color:
                      //                                                         AppTheme.Buttoncolor),
                      //                                                     borderRadius:
                      //                                                     BorderRadius
                      //                                                         .circular(
                      //                                                         10),
                      //                                                   ),
                      //                                                   focusedBorder:
                      //                                                   OutlineInputBorder(
                      //                                                     borderSide:
                      //                                                     BorderSide(
                      //                                                         color:
                      //                                                         AppTheme.Buttoncolor),
                      //                                                     borderRadius:
                      //                                                     BorderRadius
                      //                                                         .circular(
                      //                                                         10),
                      //                                                   ),
                      //                                                   contentPadding:
                      //                                                   EdgeInsets.symmetric(
                      //                                                       vertical:
                      //                                                       10,
                      //                                                       horizontal:
                      //                                                       10),
                      //                                                   hintText:
                      //                                                   'Enter your address',
                      //                                                   hintStyle:
                      //                                                   GoogleFonts
                      //                                                       .poppins(
                      //                                                     color: Colors
                      //                                                         .black,
                      //                                                     fontSize: 10,
                      //                                                     fontWeight:
                      //                                                     FontWeight
                      //                                                         .w400,
                      //                                                   ),
                      //                                                   suffixIcon:
                      //                                                   Icon(
                      //                                                     Icons
                      //                                                         .location_on_outlined,
                      //                                                     size: 20,
                      //                                                     color: AppTheme
                      //                                                         .Buttoncolor,
                      //                                                   )),
                      //                                             ),
                      //                                           ),
                      //                                           SizedBox(height: 15),
                      //                                           Obx(
                      //                                                 () =>
                      //                                                 DropdownButtonFormField<
                      //                                                     String>(
                      //                                                   value: controller
                      //                                                       .selectedCategory
                      //                                                       .value
                      //                                                       .isEmpty
                      //                                                       ? null
                      //                                                       : controller
                      //                                                       .selectedCategory
                      //                                                       .value,
                      //                                                   decoration:
                      //                                                   InputDecoration(
                      //                                                     hintText: controller
                      //                                                         .productCategoryDropdown
                      //                                                         .value,
                      //                                                     contentPadding:
                      //                                                     EdgeInsets
                      //                                                         .symmetric(
                      //                                                         vertical:
                      //                                                         10,
                      //                                                         horizontal:
                      //                                                         10),
                      //                                                     hintStyle: GoogleFonts
                      //                                                         .poppins(
                      //                                                       color:
                      //                                                       Colors.black26,
                      //                                                       fontSize: 12,
                      //                                                       fontWeight:
                      //                                                       FontWeight.w600,
                      //                                                     ),
                      //                                                     border:
                      //                                                     OutlineInputBorder(),
                      //                                                     enabledBorder:
                      //                                                     OutlineInputBorder(
                      //                                                       borderSide: BorderSide(
                      //                                                           color: AppTheme
                      //                                                               .Buttoncolor),
                      //                                                       borderRadius:
                      //                                                       BorderRadius
                      //                                                           .circular(
                      //                                                           10),
                      //                                                     ),
                      //                                                     focusedBorder:
                      //                                                     OutlineInputBorder(
                      //                                                       borderSide: BorderSide(
                      //                                                           color: AppTheme
                      //                                                               .Buttoncolor),
                      //                                                       borderRadius:
                      //                                                       BorderRadius
                      //                                                           .circular(
                      //                                                           10),
                      //                                                     ),
                      //                                                   ),
                      //                                                   items: controller
                      //                                                       .categories
                      //                                                       .map((category) =>
                      //                                                       DropdownMenuItem(
                      //                                                         value:
                      //                                                         category,
                      //                                                         child: Text(
                      //                                                             category),
                      //                                                       ))
                      //                                                       .toList(),
                      //                                                   onChanged: (value) {
                      //                                                     controller
                      //                                                         .selectedCategory
                      //                                                         .value = value ?? '';
                      //                                                     controller
                      //                                                         .productCategoryController
                      //                                                         .text = value ?? '';
                      //                                                   },
                      //                                                 ),
                      //                                           ),
                      //                                           SizedBox(height: 15),
                      //                                           Container(
                      //                                             height: 50,
                      //                                             width:
                      //                                             MediaQuery.of(context)
                      //                                                 .size
                      //                                                 .width *
                      //                                                 0.9,
                      //                                             child: TextFormField(
                      //                                               keyboardType: TextInputType.phone,
                      //                                               controller: controller
                      //                                                   .mobileNumberController,
                      //
                      //                                               decoration:
                      //                                               InputDecoration(
                      //                                                   border:
                      //                                                   OutlineInputBorder(),
                      //                                                   enabledBorder:
                      //                                                   OutlineInputBorder(
                      //                                                     borderSide:
                      //                                                     BorderSide(
                      //                                                         color:
                      //                                                         AppTheme.Buttoncolor),
                      //                                                     borderRadius:
                      //                                                     BorderRadius
                      //                                                         .circular(
                      //                                                         10),
                      //                                                   ),
                      //                                                   focusedBorder:
                      //                                                   OutlineInputBorder(
                      //                                                     borderSide:
                      //                                                     BorderSide(
                      //                                                         color:
                      //                                                         AppTheme.Buttoncolor),
                      //                                                     borderRadius:
                      //                                                     BorderRadius
                      //                                                         .circular(
                      //                                                         10),
                      //                                                   ),
                      //                                                   hintText:
                      //                                                   'Enter Your Mobile Number',
                      //                                                 hintStyle: GoogleFonts
                      //                                                     .poppins(
                      //                                                     color:
                      //                                                     Colors.black26,
                      //                                                     fontSize: 12,
                      //                                                     fontWeight:
                      //                                                     FontWeight.w600,),
                      //                                                   suffixIcon:
                      //                                                   Icon(
                      //                                                     Icons
                      //                                                         .settings_phone,
                      //                                                     size: 20,
                      //                                                     color: AppTheme
                      //                                                         .Buttoncolor,
                      //                                                   )),
                      //                                             ),
                      //                                           ),
                      //                                           SizedBox(
                      //                                             height: 15,
                      //                                           ),
                      //                                           Center(
                      //                                             child: Button(
                      //                                               widthFactor: 0.9,
                      //                                               heightFactor: 0.06,
                      //                                               onPressed: () {
                      //
                      //                                                 controller.pickupMethods.value == "delivery";
                      //                                                 controller.GetCartPlaceItemsApi();
                      //                                                 controller.GetCartApi();
                      //                                                 controller.isClicked.value = false;
                      //                                                 // PaymentDetails(
                      //                                                 //     context);
                      //                                                 // Navigator.push(
                      //                                                 //     context,
                      //                                                 //     MaterialPageRoute(
                      //                                                 //         builder:
                      //                                                 //             (context) =>
                      //                                                 //                 PaymentDetailScreen()));
                      //                                               },
                      //                                               child: controller.isLoading.value
                      //                                                   ? Container(
                      //                                                   height: height * 0.04,
                      //                                                   width: height * 0.04,
                      //                                                   child: const CircularProgressIndicator(
                      //                                                     color: Colors.white,
                      //                                                   ))
                      //                                                   : Text("Checkout".tr,
                      //                                                 style:GoogleFonts.poppins(
                      //                                                   color: Colors.white,
                      //                                                   fontSize: 20,
                      //                                                   fontWeight: FontWeight.w400,
                      //                                                 ),)
                      //                                             ),
                      //                                           ),
                      //                                         ],
                      //                                       )),
                      //                                 )
                      //                               ],
                      //                             ),
                      //                           ),
                      //                         ],
                      //                       ),
                      //                     ),
                      //                   ),
                      //                 ],
                      //               ),
                      //             ),
                      //           ),
                      //         );
                      //       },
                      //     );
                      //
                      //   }
                      // }
                      // if (!controller.isClicked.value) {
                      //   Fluttertoast.showToast(
                      //     msg:  'Choose The Product'.tr,
                      //     toastLength: Toast.LENGTH_SHORT,
                      //     gravity: ToastGravity.BOTTOM,
                      //     backgroundColor: Colors.black,
                      //     textColor: Colors.white,
                      //   );
                      // }
                      // else{
                      //   // print("MeetDate${controller.dataList[controller.selectedIndex].startTime}");
                      //   // controller.userDataProvider
                      //   //     .setSelectedMeetingTime(controller.dataList[controller.selectedIndex].startTime);
                      //   // print(controller.userDataProvider.selectedMeetingTime);
                      //   controller.paymentProcess();
                      // } for (int i = 0; i < CartProdct.length; i++) {
                      Controller.UpdateTotalPrice.value = "0";
                      for (int i = 0; i < Controller.CartProdct.length; i++) {
                        String productPrice = Controller.CartProdct[i].productPrice.toString();
                        String updatePrice = Controller.UpdateTotalPrice.value;
                        int num1 = int.parse(productPrice);
                        int num2 = int.parse(updatePrice);
                        int result = num1 + num2;
                        Controller.UpdateTotalPrice.value = result.toString();
                        print( " Total price : ${Controller.UpdateTotalPrice.value}");
                      }

                      showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return DefaultTabController(
                            length: 2,
                            child: AlertDialog(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(15),
                              ),
                              content: SingleChildScrollView(
                                child: Column(
                                  children: [
                                    SizedBox(height: 20),
                                    Row(
                                      mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          'Cart Total',
                                          style: GoogleFonts.poppins(
                                            color: Colors.black,
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                       Obx(()=>  Text(
                                         controller.UpdateTotalPrice.value,
                                         style: GoogleFonts.poppins(
                                           color: Colors.black,
                                           fontSize: 18,
                                           fontWeight: FontWeight.w500,
                                         ),
                                       ),)
                                      ],
                                    ),
                                    SizedBox(height: 15),
                                    Row(
                                      children: [
                                        Text(
                                          '9000 Young Street store',
                                          style: GoogleFonts.poppins(
                                            color: Colors.black87,
                                            fontSize: 18,
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: 15),
                                    Container(
                                      height: 400,
                                      width: MediaQuery.of(context).size.width,
                                      child: SingleChildScrollView(
                                        child: Column(
                                          children: [
                                            SizedBox(
                                              height: 45,
                                              child: Container(
                                                // decoration:
                                                // BoxDecoration(
                                                //   color: isSelected
                                                //       ? AppTheme
                                                //       .Buttoncolor
                                                //       : AppTheme
                                                //       .BorderColor,
                                                //   borderRadius:
                                                //   BorderRadius
                                                //       .circular(
                                                //       20),
                                                //   border:
                                                //   Border.all(
                                                //     color: Colors
                                                //         .orange,
                                                //   ),
                                                // ),
                                                child: TabBar(
                                                onTap: (int){

                                                },
                                                  unselectedLabelColor:
                                                  Colors.black,
                                                  indicatorSize:
                                                  TabBarIndicatorSize.tab,
                                                  indicator: BoxDecoration(
                                                      gradient: LinearGradient(
                                                          colors: [
                                                            AppTheme.Buttoncolor,
                                                            AppTheme.lightGreen
                                                          ]),
                                                      borderRadius:
                                                      BorderRadius.circular(
                                                          10),
                                                      color: Colors.redAccent),
                                                  labelColor: Colors.white,
                                                  // unselectedLabelColor:
                                                  // Colors
                                                  //     .black87,
                                                  // indicator:
                                                  // BoxDecoration(
                                                  //   color: Colors
                                                  //       .blue,
                                                  //   borderRadius:
                                                  //   BorderRadius
                                                  //       .circular(
                                                  //       5),
                                                  // ),
                                                  labelStyle: GoogleFonts.poppins(
                                                    color: Colors.white,
                                                    fontSize: 14,
                                                    fontWeight: FontWeight.w400,
                                                  ),
                                                  tabs: [
                                                    Tab(
                                                      text: 'Pickup',
                                                    ),
                                                    Tab(
                                                      text: 'Delivery',
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            SizedBox(height: 15),
                                            Container(
                                              height: 350,
                                              child: TabBarView(
                                                children: [
                                                  Container(
                                                    height: 300,
                                                    child: SingleChildScrollView(
                                                      child: Column(
                                                        children: [
                                                          // Padding(
                                                          //   padding: EdgeInsets.symmetric(
                                                          //     horizontal: 10,
                                                          //   ),
                                                          //   child: TextInput1(
                                                          //
                                                          //     label: "",
                                                          //     onPressed: () {
                                                          //       showBottomTimePicker(
                                                          //           context, controller.timeOfBirthController);
                                                          //     },
                                                          //
                                                          //     controller: controller.timeOfBirthController,
                                                          //     textInputType: TextInputType.number,
                                                          //     textColor: Color(0xCC252525),
                                                          //     hintText: "Enter Pick up Time",
                                                          //     onTextChange: (String) {},
                                                          //     sufficIcon: Icon(Icons.access_time,size: 20, color: AppTheme.Buttoncolor,),
                                                          //   ),
                                                          // ),

                                                          Container(
                                                            height: 50,
                                                            width: MediaQuery.of(
                                                                context)
                                                                .size
                                                                .width *
                                                                0.9,
                                                            child: TextFormField(
                                                              onTap: () {
                                                                showBottomTimePicker(
                                                                    context,
                                                                    controller
                                                                        .pickUptimeController);
                                                              },
                                                              readOnly: true,
                                                              controller: controller
                                                                  .pickUptimeController,
                                                              decoration:
                                                              InputDecoration(
                                                                  border:
                                                                  OutlineInputBorder(),
                                                                  enabledBorder:
                                                                  OutlineInputBorder(
                                                                    borderSide:
                                                                    BorderSide(
                                                                        color:
                                                                        AppTheme.Buttoncolor),
                                                                    borderRadius:
                                                                    BorderRadius.circular(
                                                                        10),
                                                                  ),
                                                                  focusedBorder:
                                                                  OutlineInputBorder(
                                                                    borderSide:
                                                                    BorderSide(
                                                                        color:
                                                                        AppTheme.Buttoncolor),
                                                                    borderRadius:
                                                                    BorderRadius.circular(
                                                                        10),
                                                                  ),
                                                                  hintText:
                                                                  'Choose a pick time',
                                                                  hintStyle: GoogleFonts
                                                                      .poppins(
                                                                    color:
                                                                    Colors.black26,
                                                                    fontSize: 12,
                                                                    fontWeight:
                                                                    FontWeight.w600,),
                                                                  suffixIcon:
                                                                  Icon(
                                                                    Icons
                                                                        .access_time,
                                                                    size: 20,
                                                                    color: AppTheme
                                                                        .Buttoncolor,
                                                                  )),
                                                            ),
                                                          ),
                                                          SizedBox(height: 15),
                                                          Obx(
                                                                () =>
                                                                DropdownButtonFormField<
                                                                    String>(
                                                                  value: controller
                                                                      .selectedCategory
                                                                      .value
                                                                      .isEmpty
                                                                      ? null
                                                                      : controller
                                                                      .selectedCategory
                                                                      .value,
                                                                  decoration:
                                                                  InputDecoration(
                                                                    hintText: controller
                                                                        .productCategoryDropdown
                                                                        .value,
                                                                    contentPadding:
                                                                    EdgeInsets
                                                                        .symmetric(
                                                                        vertical:
                                                                        10,
                                                                        horizontal:
                                                                        10),
                                                                    hintStyle: GoogleFonts
                                                                        .poppins(
                                                                      color:
                                                                      Colors.black26,
                                                                      fontSize: 12,
                                                                      fontWeight:
                                                                      FontWeight.w600,
                                                                    ),
                                                                    border:
                                                                    OutlineInputBorder(),
                                                                    enabledBorder:
                                                                    OutlineInputBorder(
                                                                      borderSide: BorderSide(
                                                                          color: AppTheme
                                                                              .Buttoncolor),
                                                                      borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                          10),
                                                                    ),
                                                                    focusedBorder:
                                                                    OutlineInputBorder(
                                                                      borderSide: BorderSide(
                                                                          color: AppTheme
                                                                              .Buttoncolor),
                                                                      borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                          10),
                                                                    ),
                                                                  ),
                                                                  items: controller
                                                                      .categories
                                                                      .map((category) =>
                                                                      DropdownMenuItem(
                                                                        value:
                                                                        category,
                                                                        child: Text(
                                                                            category),
                                                                      ))
                                                                      .toList(),
                                                                  onChanged: (value) {
                                                                    controller
                                                                        .selectedCategory
                                                                        .value = value ?? '';
                                                                    controller
                                                                        .productCategoryController
                                                                        .text = value ?? '';
                                                                  },
                                                                ),
                                                          ),
                                                          SizedBox(
                                                            height: 15,
                                                          ),
                                                          Container(
                                                            height: 50,
                                                            width:
                                                            MediaQuery.of(context)
                                                                .size
                                                                .width *
                                                                0.9,
                                                            child: TextFormField(
                                                              keyboardType: TextInputType.phone,
                                                              controller: controller
                                                                  .mobileNumberController,

                                                              decoration:
                                                              InputDecoration(
                                                                  border:
                                                                  OutlineInputBorder(),
                                                                  enabledBorder:
                                                                  OutlineInputBorder(
                                                                    borderSide:
                                                                    BorderSide(
                                                                        color:
                                                                        AppTheme.Buttoncolor),
                                                                    borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                        10),
                                                                  ),
                                                                  focusedBorder:
                                                                  OutlineInputBorder(
                                                                    borderSide:
                                                                    BorderSide(
                                                                        color:
                                                                        AppTheme.Buttoncolor),
                                                                    borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                        10),
                                                                  ),
                                                                  hintText:
                                                                  'Enter Your Mobile Number',
                                                                  hintStyle: GoogleFonts
                                                                      .poppins(
                                                                    color:
                                                                    Colors.black26,
                                                                    fontSize: 12,
                                                                    fontWeight:
                                                                    FontWeight.w600,),
                                                                  suffixIcon:
                                                                  Icon(
                                                                    Icons
                                                                        .settings_phone,
                                                                    size: 20,
                                                                    color: AppTheme
                                                                        .Buttoncolor,
                                                                  )),
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            height: 15,
                                                          ),
                                                          Center(
                                                            child: Button(
                                                              widthFactor: 0.9,
                                                              heightFactor: 0.06,
                                                              onPressed: () {
                                                                controller.pickupMethods.value == "PickUp";
                                                                AppPreference().updatePicUp("PickUp");
                                                                controller.GetCartPlaceItemsApi(context);
                                                                controller.DeleteCartApi();



                                                              },
                                                              child: Text(
                                                                'Checkout',
                                                                style: GoogleFonts
                                                                    .poppins(
                                                                  color:
                                                                  Colors.white,
                                                                  fontSize: 18,
                                                                  fontWeight:
                                                                  FontWeight
                                                                      .w400,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    height: 300,
                                                    child: SingleChildScrollView(
                                                        child: Column(
                                                          children: [
                                                            Container(
                                                              height: 50,
                                                              width:
                                                              MediaQuery.of(context)
                                                                  .size
                                                                  .width *
                                                                  0.9,
                                                              child: TextFormField(
                                                                readOnly: true,
                                                                controller: controller
                                                                    .addressController,
                                                                onTap: () async {

                                                                },
                                                                decoration:
                                                                InputDecoration(
                                                                    border:
                                                                    OutlineInputBorder(),
                                                                    enabledBorder:
                                                                    OutlineInputBorder(
                                                                      borderSide:
                                                                      BorderSide(
                                                                          color:
                                                                          AppTheme.Buttoncolor),
                                                                      borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                          10),
                                                                    ),
                                                                    focusedBorder:
                                                                    OutlineInputBorder(
                                                                      borderSide:
                                                                      BorderSide(
                                                                          color:
                                                                          AppTheme.Buttoncolor),
                                                                      borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                          10),
                                                                    ),
                                                                    contentPadding:
                                                                    EdgeInsets.symmetric(
                                                                        vertical:
                                                                        10,
                                                                        horizontal:
                                                                        10),
                                                                    hintText:
                                                                    'Enter your address',
                                                                    hintStyle:
                                                                    GoogleFonts
                                                                        .poppins(
                                                                      color: Colors
                                                                          .black,
                                                                      fontSize: 10,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w400,
                                                                    ),
                                                                    suffixIcon:
                                                                    Icon(
                                                                      Icons
                                                                          .location_on_outlined,
                                                                      size: 20,
                                                                      color: AppTheme
                                                                          .Buttoncolor,
                                                                    )),
                                                              ),
                                                            ),
                                                            SizedBox(height: 15),
                                                            Obx(
                                                                  () =>
                                                                  DropdownButtonFormField<
                                                                      String>(
                                                                    value: controller
                                                                        .selectedCategory
                                                                        .value
                                                                        .isEmpty
                                                                        ? null
                                                                        : controller
                                                                        .selectedCategory
                                                                        .value,
                                                                    decoration:
                                                                    InputDecoration(
                                                                      hintText: controller
                                                                          .productCategoryDropdown
                                                                          .value,
                                                                      contentPadding:
                                                                      EdgeInsets
                                                                          .symmetric(
                                                                          vertical:
                                                                          10,
                                                                          horizontal:
                                                                          10),
                                                                      hintStyle: GoogleFonts
                                                                          .poppins(
                                                                        color:
                                                                        Colors.black26,
                                                                        fontSize: 12,
                                                                        fontWeight:
                                                                        FontWeight.w600,
                                                                      ),
                                                                      border:
                                                                      OutlineInputBorder(),
                                                                      enabledBorder:
                                                                      OutlineInputBorder(
                                                                        borderSide: BorderSide(
                                                                            color: AppTheme
                                                                                .Buttoncolor),
                                                                        borderRadius:
                                                                        BorderRadius
                                                                            .circular(
                                                                            10),
                                                                      ),
                                                                      focusedBorder:
                                                                      OutlineInputBorder(
                                                                        borderSide: BorderSide(
                                                                            color: AppTheme
                                                                                .Buttoncolor),
                                                                        borderRadius:
                                                                        BorderRadius
                                                                            .circular(
                                                                            10),
                                                                      ),
                                                                    ),
                                                                    items: controller
                                                                        .categories
                                                                        .map((category) =>
                                                                        DropdownMenuItem(
                                                                          value:
                                                                          category,
                                                                          child: Text(
                                                                              category),
                                                                        ))
                                                                        .toList(),
                                                                    onChanged: (value) {
                                                                      controller
                                                                          .selectedCategory
                                                                          .value = value ?? '';
                                                                      controller
                                                                          .productCategoryController
                                                                          .text = value ?? '';
                                                                    },
                                                                  ),
                                                            ),
                                                            SizedBox(height: 15),
                                                            Container(
                                                              height: 50,
                                                              width:
                                                              MediaQuery.of(context)
                                                                  .size
                                                                  .width *
                                                                  0.9,
                                                              child: TextFormField(
                                                                keyboardType: TextInputType.phone,
                                                                controller: controller
                                                                    .mobileNumberController,

                                                                decoration:
                                                                InputDecoration(
                                                                    border:
                                                                    OutlineInputBorder(),
                                                                    enabledBorder:
                                                                    OutlineInputBorder(
                                                                      borderSide:
                                                                      BorderSide(
                                                                          color:
                                                                          AppTheme.Buttoncolor),
                                                                      borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                          10),
                                                                    ),
                                                                    focusedBorder:
                                                                    OutlineInputBorder(
                                                                      borderSide:
                                                                      BorderSide(
                                                                          color:
                                                                          AppTheme.Buttoncolor),
                                                                      borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                          10),
                                                                    ),
                                                                    hintText:
                                                                    'Enter Your Mobile Number',
                                                                    hintStyle: GoogleFonts
                                                                        .poppins(
                                                                      color:
                                                                      Colors.black26,
                                                                      fontSize: 12,
                                                                      fontWeight:
                                                                      FontWeight.w600,),
                                                                    suffixIcon:
                                                                    Icon(
                                                                      Icons
                                                                          .settings_phone,
                                                                      size: 20,
                                                                      color: AppTheme
                                                                          .Buttoncolor,
                                                                    )),
                                                              ),
                                                            ),
                                                            SizedBox(
                                                              height: 15,
                                                            ),
                                                            Center(
                                                              child: Button(
                                                                  widthFactor: 0.9,
                                                                  heightFactor: 0.06,
                                                                  onPressed: () {

                                                                    controller.pickupMethods.value == "delivery";
                                                                    AppPreference().updateDelivery("delivery");
                                                                    controller.GetCartPlaceItemsApi(context);
                                                                    controller.DeleteCartApi();
                                                                    Get.back();
                                                                  },
                                                                  child: controller.isLoading.value
                                                                      ? Container(
                                                                      height: height * 0.04,
                                                                      width: height * 0.04,
                                                                      child: const CircularProgressIndicator(
                                                                        color: Colors.white,
                                                                      ))
                                                                      : Text("Checkout".tr,
                                                                    style:GoogleFonts.poppins(
                                                                      color: Colors.white,
                                                                      fontSize: 20,
                                                                      fontWeight: FontWeight.w400,
                                                                    ),)
                                                              ),
                                                            ),
                                                          ],
                                                        )),
                                                  )
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      );


                    },
                    child: Text(
                      "Checkout", //bottomsheet button
                      style: GoogleFonts.poppins(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ),
                ),
              ),
            ],
            // backgroundColor: AppTheme.Buttoncolor,
            appBar: AppBar(
              backgroundColor: AppTheme.Buttoncolor,
              automaticallyImplyLeading: false,
              bottomOpacity: 0.0,
              elevation: 0.0,
              toolbarHeight: 80,
              // leading: Padding(
              //   padding: EdgeInsets.only(top: 20, bottom: 20, right: 0, left: 15),
              //   child: InkWell(
              //     onTap: () {
              //       Navigator.pop(context);
              //     },
              //     child: Container(
              //       decoration: BoxDecoration(
              //           color: Colors.green.shade700,
              //           borderRadius: BorderRadius.circular(10)),
              //       margin: EdgeInsets.symmetric(
              //         horizontal: 2,
              //       ),
              //       child: Icon(
              //         Icons.arrow_back_ios_new,
              //         color: Colors.white, // customize color as per requirement
              //       ),
              //     ),
              //   ),
              // ),
              title: Text("My cart detail",
                  style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  )),
              centerTitle: true,
              actions: <Widget>[],
            ),
            body: SingleChildScrollView(
              child: Container(
                height: MediaQuery.of(context).size.height,
                decoration: BoxDecoration(
                    color: AppTheme.ScreenBackground,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(25),
                        topRight: Radius.circular(25))),
                child: Obx(
                  () => Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: controller.isLoading.value
                        ? Container(
                            height: MediaQuery.of(context).size.height * 0.60,
                            child: Center(child: CircularProgressIndicator()))
                        : controller.CartProdct!.value.isNotEmpty
                            ? Container(
                                height: MediaQuery.of(context).size.height,
                                child: Column(
                                  children: [
                                    Row(children: [
                                      SizedBox(
                                        height:
                                            MediaQuery.of(context).size.height *
                                                0.02,
                                      )
                                    ]),
                                    SingleChildScrollView(
                                      child: Column(children: [
                                        Container(
                                          height: MediaQuery.of(context)
                                                  .size
                                                  .height *
                                              0.71,
                                          child: SingleChildScrollView(
                                            child: GridView.count(
                                              physics:
                                                  NeverScrollableScrollPhysics(),
                                              crossAxisCount: 1,
                                              childAspectRatio: 3,
                                              shrinkWrap: true,
                                              children: List.generate(
                                                Controller.CartProdct.length,
                                                (index) {
                                                  return Card.filled(
                                                    shadowColor: Colors.grey,
                                                    color: Colors.white,
                                                    //surfaceTintColor: Colors.grey,
                                                    elevation: 5,
                                                    shape:
                                                        RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10),
                                                    ),
                                                    child: Row(
                                                      // mainAxisAlignment:
                                                      //     MainAxisAlignment.spaceEvenly,
                                                      children: [
                                                        // Obx(() => Checkbox(
                                                        //       value: controller
                                                        //               .onClickList[
                                                        //           index],
                                                        //       onChanged: (bool?
                                                        //           value) {
                                                        //         if (value !=
                                                        //             null) {
                                                        //           controller.onClickList[
                                                        //                   index] =
                                                        //               !controller
                                                        //                       .onClickList[
                                                        //                   index];
                                                        //         }
                                                        //         controller
                                                        //             .UpdateTotalPrice
                                                        //             .value = "0";
                                                        //         controller
                                                        //                 .CartProdctList
                                                        //             .clear();
                                                        //
                                                        //
                                                        //
                                                        //
                                                        //
                                                        //         for (int i = 0; i < controller.onClickList.length; i++) {
                                                        //           // Check if the value at the current index is true
                                                        //           if (controller
                                                        //                   .onClickList[
                                                        //               i]) {
                                                        //             // Add the item from CartProdctList at the same index to CartProdctList
                                                        //
                                                        //             controller
                                                        //                     .CartProdctList
                                                        //                 .add(controller
                                                        //                     .CartProdct[i]);
                                                        //             controller.selectedIndexOne.value = controller
                                                        //                 .CartProdct[
                                                        //             i]
                                                        //                 .sellerId!;
                                                        //             String productPrice = controller
                                                        //                 .CartProdct[
                                                        //                     i]
                                                        //                 .productPrice
                                                        //                 .toString();
                                                        //             String
                                                        //                 updatePrice =
                                                        //                 controller
                                                        //                     .UpdateTotalPrice
                                                        //                     .value;
                                                        //             int num1 =
                                                        //                 int.parse(
                                                        //                     productPrice);
                                                        //             int num2 =
                                                        //                 int.parse(
                                                        //                     updatePrice);
                                                        //
                                                        //             int result =
                                                        //                 num1 +
                                                        //                     num2;
                                                        //             controller
                                                        //                     .UpdateTotalPrice
                                                        //                     .value =
                                                        //                 result
                                                        //                     .toString();
                                                        //             log("CartProductList${json.encode(controller.CartProdctList)}");
                                                        //             controller
                                                        //                 .placeOrderItems
                                                        //                 .clear();
                                                        //             for (int i =
                                                        //                     0;
                                                        //                 i < controller.CartProdctList.length;
                                                        //                 i++) {
                                                        //               PlaceOrderItemsResponse
                                                        //                   placeItems =
                                                        //                   PlaceOrderItemsResponse();
                                                        //
                                                        //               placeItems.productName = controller
                                                        //                   .CartProdct[
                                                        //                       index]
                                                        //                   .productName
                                                        //                   .toString();
                                                        //
                                                        //               placeItems
                                                        //                       .productId =
                                                        //                   controller
                                                        //                       .CartProdct[index]
                                                        //                       .id.toString();
                                                        //               placeItems.productPrice = controller
                                                        //                   .CartProdct[
                                                        //                       index]
                                                        //                   .productPrice
                                                        //                   .toString();
                                                        //               placeItems.productQty = controller
                                                        //                   .CartProdct[
                                                        //                       index]
                                                        //                   .productQty
                                                        //                   .toString();
                                                        //               placeItems
                                                        //                       .orderedQty =
                                                        //                   controller
                                                        //                       .counter[index]
                                                        //                       .toString();
                                                        //               controller
                                                        //                   .placeOrderItems
                                                        //                   .add(
                                                        //                       placeItems);
                                                        //             }
                                                        //           }
                                                        //         }
                                                        //       },
                                                        //       activeColor: AppTheme
                                                        //           .Buttoncolor,
                                                        //     )),
                                                        CartCommonComponent(
                                                          productImage: controller
                                                                  .CartProdct[
                                                                      index]
                                                                  .productImage ??
                                                              "",
                                                          productName: controller
                                                                  .CartProdct[
                                                                      index]
                                                                  .productName ??
                                                              "",
                                                          productQty: controller
                                                                  .CartProdct[
                                                                      index]
                                                                  .productQty ??
                                                              "",
                                                          productPrice: controller
                                                                  .CartProdct[
                                                                      index]
                                                                  .productPrice
                                                                  .toString() ??
                                                              "",
                                                          productDescription:
                                                              controller
                                                                      .CartProdct[
                                                                          index]
                                                                      .productDescription ??
                                                                  "",
                                                          OnPressed: () {
                                                            controller.index =
                                                                index;
                                                            controller
                                                                .DeleteCartApi();
                                                          },
                                                          decrementCounter: () {
                                                            controller
                                                                .decrementCounter(
                                                                    index);
                                                            // controller
                                                            //     .onClickCounterList[
                                                            // index];
                                                          },
                                                          incrementCounter: () {
                                                            controller
                                                                .incrementCounter(
                                                                    index);
                                                            // controller
                                                            //     .onClickCounterList[
                                                            // index];
                                                          },
                                                          counter: controller
                                                              .counter[index]
                                                              .value,
                                                        )
                                                      ],
                                                    ),
                                                  );
                                                },
                                              ),
                                            ),
                                          ),
                                        ),
                                      ]),
                                    )
                                  ],
                                ),
                              )
                            : Center(
                                child: Container(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      SizedBox(height: 100),
                                      Image.asset("assets/images/nodata.png"),
                                      SizedBox(height: 20),
                                    ],
                                  ),
                                ),
                              ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  showBottomTimePicker(
    BuildContext context,
    TextEditingController controller,
  ) {
    var times;
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(16.0),
          topRight: Radius.circular(16.0),
        ),
      ),
      isScrollControlled: true,
      context: context,
      builder: (BuildContext context) {
        return Builder(
          builder: (BuildContext context) {
            return Container(
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(10)),
              height: 280,
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(
                        left: 10, right: 10, top: 15, bottom: 7),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(height: 20, width: 20),
                        Expanded(
                          child: Container(
                            alignment: Alignment.center,
                            child: Text("Select Time",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    color: AppTheme.appBlack,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold)),
                          ),
                        ),
                        GestureDetector(
                            onTap: () {
                              Get.back();
                            },
                            child: Icon(Icons.clear))
                      ],
                    ),
                  ),
                  Expanded(
                    child: TimePickerSpinner(
                      is24HourMode: false,
                      spacing: 30,
                      itemHeight: 37,
                      itemWidth: 60,
                      isForce2Digits: true,
                      onTimeChange: (time) {
                        times = time;
                      },
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      AppButton2(
                        width: width * 0.45,
                        height: 40,
                        title: 'Cancel',
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        onPressed: () {
                          Get.back();
                        },
                        color: Colors.white,
                        titleColor: AppTheme.bottomTabsLabelInActiveColor,
                        borderColor: AppTheme.cancelBorder,
                      ),
                      AppButton2(
                        width: width * 0.45,
                        height: 40,
                        title: 'Save ',
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        onPressed: () {
                          controller.text = " ${formatDate(times, [
                                hh,
                                ':',
                                nn,
                                ' ',
                                am,
                              ])}";
                          Navigator.of(context).pop();
                        },
                        titleColor: Colors.white,
                        color: AppTheme.Buttoncolor,
                        borderColor: AppTheme.Buttoncolor,
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
// Widget PaymentDetails(BuildContext context) {
//   return GetBuilder<CartScreenController>(
//     init: CartScreenController(),
//     builder: (controller) {
//       return Scaffold(
//         backgroundColor: AppTheme.Buttoncolor,
//         appBar: AppBar(
//           backgroundColor: AppTheme.Buttoncolor,
//           automaticallyImplyLeading: false,
//           bottomOpacity: 0.0,
//           elevation: 0.0,
//           toolbarHeight: 80,
//           leading: Padding(
//             padding: EdgeInsets.only(top: 20, bottom: 20, right: 0, left: 15),
//             child: InkWell(
//               onTap: () {
//                 Navigator.of(context);
//               },
//               child: Container(
//                 decoration: BoxDecoration(
//                     color: Colors.green.shade700,
//                     borderRadius: BorderRadius.circular(10)),
//                 margin: EdgeInsets.symmetric(
//                   horizontal: 2,
//                 ),
//                 child: Icon(
//                   Icons.arrow_back_ios_new,
//                   color: Colors.white, // customize color as per requirement
//                 ),
//               ),
//             ),
//           ),
//           title: Text("Payment detail",
//               style: TextStyle(
//                 color: Colors.white,
//                 fontSize: 20,
//                 fontWeight: FontWeight.w600,
//               )),
//           centerTitle: true,
//           actions: <Widget>[],
//         ),
//         body: Container(
//           height: MediaQuery.of(context).size.height,
//           // width: MediaQuery.of(context).size.width,
//           decoration: BoxDecoration(
//               color: Colors.white,
//               borderRadius: BorderRadius.only(
//                   topLeft: Radius.circular(25),
//                   topRight: Radius.circular(25))),
//           child: SingleChildScrollView(
//             child: Column(
//               children: [
//                 SizedBox(
//                   height: MediaQuery.of(context).size.height * 0.02,
//                 ),
//                 Padding(
//                   padding: EdgeInsets.symmetric(
//                     horizontal: 20,
//                   ),
//                   child: Row(
//                     children: [
//                       Text(
//                         'Total Amount',
//                         style: TextStyle(
//                             fontSize: 20,
//                             fontWeight: FontWeight.w700,
//                             color: Colors.black),
//                       )
//                     ],
//                   ),
//                 ),
//                 Padding(
//                   padding: const EdgeInsets.symmetric(
//                       horizontal: 20, vertical: 15),
//                   child: TextFormField(
//                     decoration: InputDecoration(
//                       border: OutlineInputBorder(),
//                       enabledBorder: OutlineInputBorder(
//                         borderSide: BorderSide(color: AppTheme.Buttoncolor),
//                         borderRadius: BorderRadius.circular(25),
//                       ),
//                       focusedBorder: OutlineInputBorder(
//                         borderSide: BorderSide(color: AppTheme.Buttoncolor),
//                         borderRadius: BorderRadius.circular(20),
//                       ),
//                       hintText: '   CAD\$11.52',
//                       hintStyle: TextStyle(
//                           fontSize: 15,
//                           fontWeight: FontWeight.w400,
//                           color: Colors.black26),
//                     ),
//                     style: TextStyle(
//                         fontSize: 15,
//                         fontWeight: FontWeight.w400,
//                         color: Colors.black26),
//                   ),
//                 ),
//                 Padding(
//                   padding: EdgeInsets.symmetric(horizontal: 20),
//                   child: Row(
//                     mainAxisAlignment: MainAxisAlignment.start,
//                     children: [
//                       Text(
//                         'Payment method',
//                         style: TextStyle(
//                             fontSize: 20,
//                             fontWeight: FontWeight.w700,
//                             color: Colors.black),
//                       )
//                     ],
//                   ),
//                 ),
//                 Padding(
//                   padding: EdgeInsets.symmetric(
//                     horizontal: 20,
//                     vertical: 15,
//                   ),
//                   child: TextFormField(
//                     decoration: InputDecoration(
//                       border: OutlineInputBorder(),
//                       enabledBorder: OutlineInputBorder(
//                         borderSide: BorderSide(color: AppTheme.Buttoncolor),
//                         borderRadius: BorderRadius.circular(25),
//                       ),
//                       focusedBorder: OutlineInputBorder(
//                         borderSide: BorderSide(color: AppTheme.Buttoncolor),
//                         borderRadius: BorderRadius.circular(20),
//                       ),
//                       hintText: '   Credit card',
//                       hintStyle: TextStyle(
//                           fontSize: 15,
//                           fontWeight: FontWeight.w400,
//                           color: Colors.black26),
//                       suffixIcon: Icon(Icons.keyboard_arrow_down,
//                           size: 35, color: Colors.black26),
//                     ),
//                     style: TextStyle(
//                         fontSize: 15,
//                         fontWeight: FontWeight.w400,
//                         color: Colors.black26),
//                   ),
//                 ),
//                 Padding(
//                   padding: EdgeInsets.symmetric(horizontal: 20),
//                   child: Row(
//                     mainAxisAlignment: MainAxisAlignment.start,
//                     children: [
//                       Text(
//                         'Car expirated date',
//                         style: TextStyle(
//                             fontSize: 20,
//                             fontWeight: FontWeight.w700,
//                             color: Colors.black),
//                       )
//                     ],
//                   ),
//                 ),
//                 Padding(
//                     padding: const EdgeInsets.symmetric(
//                         horizontal: 20, vertical: 15),
//                     child: Row(
//                       children: [
//                         Expanded(
//                           child: Padding(
//                             padding: const EdgeInsets.only(right: 5),
//                             child: TextFormField(
//                               decoration: InputDecoration(
//                                 border: OutlineInputBorder(),
//                                 enabledBorder: OutlineInputBorder(
//                                   borderSide:
//                                       BorderSide(color: AppTheme.Buttoncolor),
//                                   borderRadius: BorderRadius.circular(25),
//                                 ),
//                                 focusedBorder: OutlineInputBorder(
//                                   borderSide:
//                                       BorderSide(color: AppTheme.Buttoncolor),
//                                   borderRadius: BorderRadius.circular(20),
//                                 ),
//                                 hintText: '   dd/mm/yyyy',
//                                 hintStyle: TextStyle(
//                                   fontSize: 15,
//                                   fontWeight: FontWeight.w400,
//                                   color: Colors.black26,
//                                 ),
//                                 suffixIcon: Icon(
//                                   Icons.keyboard_arrow_down,
//                                   size: 35,
//                                   color: Colors.black26,
//                                 ),
//                               ),
//                               style: TextStyle(
//                                 fontSize: 15,
//                                 fontWeight: FontWeight.w400,
//                                 color: Colors.black26,
//                               ),
//                             ),
//                           ),
//                         ),
//                         Expanded(
//                           child: Padding(
//                             padding: const EdgeInsets.only(left: 5),
//                             child: TextFormField(
//                               decoration: InputDecoration(
//                                 border: OutlineInputBorder(),
//                                 enabledBorder: OutlineInputBorder(
//                                   borderSide:
//                                       BorderSide(color: AppTheme.Buttoncolor),
//                                   borderRadius: BorderRadius.circular(25),
//                                 ),
//                                 focusedBorder: OutlineInputBorder(
//                                   borderSide:
//                                       BorderSide(color: AppTheme.Buttoncolor),
//                                   borderRadius: BorderRadius.circular(20),
//                                 ),
//                                 hintText: '   dd/mm/yyyy',
//                                 hintStyle: TextStyle(
//                                   fontSize: 15,
//                                   fontWeight: FontWeight.w400,
//                                   color: Colors.black26,
//                                 ),
//                                 suffixIcon: Icon(
//                                   Icons.keyboard_arrow_down,
//                                   size: 35,
//                                   color: Colors.black26,
//                                 ),
//                               ),
//                               style: TextStyle(
//                                 fontSize: 15,
//                                 fontWeight: FontWeight.w400,
//                                 color: Colors.black26,
//                               ),
//                             ),
//                           ),
//                         ),
//                       ],
//                     )),
//                 Padding(
//                   padding: const EdgeInsets.symmetric(horizontal: 20),
//                   child: Row(
//                     mainAxisAlignment: MainAxisAlignment.start,
//                     children: [
//                       Text(
//                         'Card number',
//                         style: TextStyle(
//                             fontSize: 20,
//                             fontWeight: FontWeight.w700,
//                             color: Colors.black),
//                       )
//                     ],
//                   ),
//                 ),
//                 Padding(
//                   padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
//                   child: TextFormField(
//                     decoration: InputDecoration(
//                       border: OutlineInputBorder(),
//                       enabledBorder: OutlineInputBorder(
//                         borderSide: BorderSide(color: AppTheme.Buttoncolor),
//                         borderRadius: BorderRadius.circular(25),
//                       ),
//                       focusedBorder: OutlineInputBorder(
//                         borderSide: BorderSide(color: AppTheme.Buttoncolor),
//                         borderRadius: BorderRadius.circular(20),
//                       ),
//                       hintText: '   Account number',
//                       hintStyle: TextStyle(
//                         fontSize: 15,
//                         fontWeight: FontWeight.w400,
//                         color: Colors.black26,
//                       ),
//                       suffixIcon: Icon(Icons.keyboard_arrow_down,
//                           size: 35, color: Colors.black26),
//                     ),
//                     style: TextStyle(
//                       fontSize: 15,
//                       fontWeight: FontWeight.w400,
//                       color: Colors.black26,
//                     ),
//                   ),
//                 ),
//                 Padding(
//                   padding: const EdgeInsets.symmetric(horizontal: 20),
//                   child: Row(
//                     mainAxisAlignment: MainAxisAlignment.start,
//                     children: [
//                       Text(
//                         'Security code',
//                         style: TextStyle(
//                           fontSize: 20,
//                           fontWeight: FontWeight.w700,
//                           color: Colors.black,
//                         ),
//                       )
//                     ],
//                   ),
//                 ),
//                 Padding(
//                   padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
//                   child: TextFormField(
//                     decoration: InputDecoration(
//                       border: OutlineInputBorder(),
//                       enabledBorder: OutlineInputBorder(
//                         borderSide: BorderSide(color: AppTheme.Buttoncolor),
//                         borderRadius: BorderRadius.circular(25),
//                       ),
//                       focusedBorder: OutlineInputBorder(
//                         borderSide: BorderSide(color: AppTheme.Buttoncolor),
//                         borderRadius: BorderRadius.circular(20),
//                       ),
//                       hintText: '   Security code',
//                       hintStyle: TextStyle(
//                           fontSize: 15,
//                           fontWeight: FontWeight.w400,
//                           color: Colors.black26),
//                       suffixIcon: Icon(Icons.keyboard_arrow_down,
//                           size: 35, color: Colors.black26),
//                     ),
//                     style: TextStyle(
//                         fontSize: 15,
//                         fontWeight: FontWeight.w400,
//                         color: Colors.black26),
//                   ),
//                 ),
//                 SizedBox(
//                   height: MediaQuery.of(context).size.height * 0.02,
//                 ),
//                 Center(
//                   child: Button(
//                     widthFactor: 0.9,
//                     heightFactor: 0.06,
//                     onPressed: () {
//                       // Navigator.push(
//                       //     context,
//                       //     MaterialPageRoute(
//                       //         builder: (context) => CreateAccountScreen()));
//                     },
//                     child: const Text(
//                       "Pay now",
//                       style: TextStyle(
//                         fontSize: 18,
//                         color: Colors.white,
//                         fontWeight: FontWeight.w600,
//                       ),
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       );
//     },
//   );
// }
}
