import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:grosshop/Components/AppTheme.dart';
import 'package:grosshop/UI/HomeScreen/ProductHomeScreen.dart';


import '../UI/CartScreen/CartScreen.dart';
import '../UI/OfferDetailScreens/OfferScreen.dart';
import '../UI/MyOrderScreens/OrderListPage.dart';
import '../UI/SettingsScreen/SettingScreen.dart';

class navigateBar extends StatefulWidget {
  navigateBar({Key? key}) : super(key: key);

  @override
  State<navigateBar> createState() => _navigateBarState();
}

class _navigateBarState extends State<navigateBar> {
  int _currentpage = 0;
  late List<Widget> page = [
    ProductHomeScreen(),
    CartScreen(),
    OrderListScreen(),
    OfferScreen(),
    SettingScreen(),
  ];
  int _lastTapTime = 0;
  int _lastTapIndex = 0;

  void onTap(int index) {
    final currentTime = DateTime.now().millisecondsSinceEpoch;
    if (_lastTapIndex == index && currentTime - _lastTapTime < 500) {
      if (index == 0) {
        print('double tap');
        // Navigator.push(
        //   context,
        //   MaterialPageRoute(builder: (context) => navigateBar()),
        // );
      }
    } else {
      setState(() {
        _currentpage = index;
      });
    }

    _lastTapIndex = index;
    _lastTapTime = currentTime;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: page[_currentpage],
      bottomNavigationBar: BottomNavigationBar(
        selectedFontSize: 10,
        selectedItemColor: AppTheme.Buttoncolor,
        unselectedItemColor: Colors.black87,
        unselectedFontSize: 10,
        showUnselectedLabels: true,
        showSelectedLabels: true,
        currentIndex: _currentpage,
        onTap: onTap,
        selectedIconTheme: IconThemeData(color: AppTheme.Buttoncolor),
        selectedLabelStyle: TextStyle(
          color: AppTheme.Buttoncolor,
          fontWeight: FontWeight.w400,
          fontSize: 10,
        ),
        //
        unselectedIconTheme: IconThemeData(
          color: Colors.black26,
        ),
        unselectedLabelStyle: TextStyle(
          color: Colors.black,
          fontWeight: FontWeight.bold,
          fontSize: 10,
        ),
        items: [
          BottomNavigationBarItem(
            icon: Icon(
              Icons.home_sharp,
            ),
            label: 'Home',
          ),
          BottomNavigationBarItem(
              label: 'Cart',
              icon: Icon(
                Icons.shopping_basket_outlined,
                size: 32,
              )),
          BottomNavigationBarItem(
              label: 'My order',
              icon: Icon(
                Icons.shopping_bag_outlined,
                size: 32,
              )),
          BottomNavigationBarItem(
              label: 'Offer',
              icon: Icon(
                Icons.card_giftcard_sharp,
                size: 32,
              )),
          BottomNavigationBarItem(
              label: 'Setting',
              icon: Icon(
                Icons.settings,
                size: 32,
              )),
        ],
      ),
    );
  }
}
